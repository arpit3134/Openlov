import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { EditorialCard } from "@/components/EditorialCard";
import { ResourceCard } from "@/components/ResourceCard";
import { RichFooter } from "@/components/RichFooter";
import { collections, articles, resources } from "@/data/mockData";

export default function CollectionDetail() {
  const { slug } = useParams();
  const [searchOpen, setSearchOpen] = useState(false);
  const collection = collections.find((c) => c.slug === slug);

  if (!collection) {
    return (
      <div className="min-h-screen bg-background">
        <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
        <div className="container py-32 text-center">
          <h1 className="font-editorial text-3xl text-foreground mb-4">Collection not found</h1>
          <Link to="/collections" className="text-primary hover:underline">Browse collections</Link>
        </div>
        <RichFooter />
      </div>
    );
  }

  const collectionArticles = articles.filter((a) => a.topic === collection.topic).slice(0, 4);
  const collectionResources = resources.filter((r) => r.topic === collection.topic).slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <section className="pt-12 pb-8">
        <div className="container">
          <nav className="flex items-center gap-2 text-xs text-muted-foreground mb-6">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <span>/</span>
            <Link to="/collections" className="hover:text-foreground transition-colors">Collections</Link>
            <span>/</span>
            <span className="text-foreground">{collection.title}</span>
          </nav>
          <div className="relative rounded-xl overflow-hidden mb-8 aspect-[3/1]">
            <img src={collection.coverImage} alt={collection.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 to-transparent" />
            <div className="absolute bottom-0 left-0 p-8">
              <span className="text-xs text-primary-foreground/60 uppercase tracking-wider">{collection.itemCount} items</span>
              <h1 className="font-editorial text-3xl md:text-4xl font-medium text-primary-foreground mt-1">{collection.title}</h1>
              <p className="text-sm text-primary-foreground/80 mt-2 max-w-xl">{collection.description}</p>
            </div>
          </div>
        </div>
      </section>

      {collectionArticles.length > 0 && (
        <section className="pb-12">
          <div className="container">
            <h2 className="font-editorial text-2xl font-medium text-foreground mb-6">Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {collectionArticles.map((a) => <EditorialCard key={a.id} article={a} />)}
            </div>
          </div>
        </section>
      )}

      {collectionResources.length > 0 && (
        <section className="pb-16">
          <div className="container">
            <h2 className="font-editorial text-2xl font-medium text-foreground mb-6">Resources</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {collectionResources.map((r) => <ResourceCard key={r.id} resource={r} />)}
            </div>
          </div>
        </section>
      )}

      <RichFooter />
    </div>
  );
}
