import { useState } from "react";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { RichFooter } from "@/components/RichFooter";
import { TrendingUp } from "lucide-react";

export default function TrendingPage() {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <section className="pt-12 pb-16">
        <div className="container">
          <h1 className="font-editorial text-3xl md:text-4xl font-medium text-foreground mb-2">Trending</h1>
          <p className="text-muted-foreground mb-10">What the internet is talking about right now</p>
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <TrendingUp className="w-12 h-12 text-muted-foreground/40 mb-4" />
            <p className="text-lg font-medium text-foreground mb-1">Nothing trending yet</p>
            <p className="text-sm text-muted-foreground max-w-md">Trending content will appear here as it's published.</p>
          </div>
        </div>
      </section>

      <RichFooter />
    </div>
  );
}
