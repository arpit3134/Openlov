import { useState, useMemo } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { StickyHeader } from "@/components/StickyHeader";
import { RichFooter } from "@/components/RichFooter";
import { calculators } from "@/data/calculators";

const CalculatorDetail = () => {
  const { slug } = useParams();
  const calc = calculators.find((c) => c.slug === slug);

  const [values, setValues] = useState<Record<string, any>>(() => {
    if (!calc) return {};
    const init: Record<string, any> = {};
    calc.inputs.forEach((i) => {
      init[i.key] = i.default ?? "";
    });
    return init;
  });

  const results = useMemo(() => {
    if (!calc) return [];
    try {
      return calc.calculate(values);
    } catch {
      return [];
    }
  }, [values, calc]);

  const updateValue = (key: string, value: any) => {
    setValues((prev) => ({ ...prev, [key]: value }));
  };

  if (!calc) {
    return (
      <div className="min-h-screen bg-background">
        <StickyHeader />
        <div className="container py-20 text-center">
          <h1 className="font-editorial text-3xl text-foreground mb-4">Calculator not found</h1>
          <Link to="/calculators" className="text-primary hover:underline">Browse all calculators</Link>
        </div>
        <RichFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader />
      <motion.div className="container max-w-4xl py-10 md:py-14" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45, ease: [0.2, 0.8, 0.2, 1] }}>
        <Link
          to="/calculators"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Calculators
        </Link>

        <h1 className="font-editorial text-3xl md:text-4xl font-medium text-foreground mb-2">{calc.name}</h1>
        <p className="text-muted-foreground mb-8">{calc.description}</p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Inputs */}
          <div className="rounded-xl border border-border bg-card p-6">
            <h2 className="font-medium text-foreground mb-4 text-sm uppercase tracking-wider">Inputs</h2>
            <div className="space-y-4">
              {calc.inputs.map((input) => (
                <div key={input.key}>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">{input.label}</label>
                  {input.type === "number" && (
                    <div className="relative">
                      {input.prefix && (
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">{input.prefix}</span>
                      )}
                      <input
                        type="number"
                        value={values[input.key]}
                        onChange={(e) => updateValue(input.key, e.target.value === "" ? "" : parseFloat(e.target.value))}
                        min={input.min}
                        max={input.max}
                        step={input.step || 1}
                        placeholder={input.placeholder}
                        className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        style={{ paddingLeft: input.prefix ? "2rem" : undefined, paddingRight: input.suffix ? "3rem" : undefined }}
                      />
                      {input.suffix && (
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">{input.suffix}</span>
                      )}
                    </div>
                  )}
                  {input.type === "select" && (
                    <select
                      value={values[input.key]}
                      onChange={(e) => updateValue(input.key, e.target.value)}
                      className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      {input.options?.map((opt) => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                  )}
                  {input.type === "text" && (
                    <input
                      type="text"
                      value={values[input.key]}
                      onChange={(e) => updateValue(input.key, e.target.value)}
                      placeholder={input.placeholder}
                      className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  )}
                  {input.type === "textarea" && (
                    <textarea
                      value={values[input.key]}
                      onChange={(e) => updateValue(input.key, e.target.value)}
                      placeholder={input.placeholder}
                      rows={6}
                      className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground font-mono focus:outline-none focus:ring-2 focus:ring-ring resize-y"
                    />
                  )}
                  {input.type === "date" && (
                    <input
                      type="date"
                      value={values[input.key]}
                      onChange={(e) => updateValue(input.key, e.target.value)}
                      className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Results */}
          <div className="space-y-3">
            <h2 className="font-medium text-foreground mb-1 text-sm uppercase tracking-wider">Results</h2>
            {results.length > 0 ? (
              results.map((r, i) => (
                <div
                  key={i}
                  className={`rounded-xl border p-5 ${r.highlight ? "bg-primary/5 border-primary/20" : "border-border bg-card"}`}
                >
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{r.label}</p>
                  {r.type === "code" ? (
                    <pre className="mt-1 text-sm font-mono bg-secondary/50 rounded-lg p-3 overflow-auto max-h-64 text-foreground whitespace-pre-wrap break-all">{r.value}</pre>
                  ) : (
                    <p className={`text-xl font-semibold mt-0.5 ${r.highlight ? "text-primary" : "text-foreground"}`}>{r.value}</p>
                  )}
                </div>
              ))
            ) : (
              <div className="rounded-xl border border-border bg-card p-8 text-center">
                <p className="text-muted-foreground text-sm">Enter values to see results</p>
              </div>
            )}
          </div>
        </div>
      </motion.div>
      <RichFooter />
    </div>
  );
};

export default CalculatorDetail;
