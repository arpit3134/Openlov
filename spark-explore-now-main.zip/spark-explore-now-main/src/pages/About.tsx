import { useState } from "react";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { RichFooter } from "@/components/RichFooter";

export default function AboutPage() {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <section className="pt-16 pb-20">
        <div className="container max-w-2xl">
          <h1 className="font-editorial text-4xl md:text-5xl font-medium text-foreground mb-6">About Signal</h1>
          <div className="space-y-6 text-muted-foreground leading-relaxed">
            <p className="text-lg">
              Signal is a modern discovery platform designed to help curious minds explore what matters across the internet.
            </p>
            <p>
              In a world overflowing with information, finding what's truly worth your attention has never been harder. Signal cuts through the noise by curating the best articles, tools, resources, and insights across technology, science, business, design, and more.
            </p>
            <p>
              We believe in the power of editorial curation combined with intelligent discovery. Every piece of content on Signal is selected for its quality, relevance, and ability to spark new thinking.
            </p>
            <p>
              Whether you're a founder exploring new ideas, a researcher staying current, a designer seeking inspiration, or simply someone who loves learning — Signal is built for you.
            </p>
          </div>
        </div>
      </section>

      <RichFooter />
    </div>
  );
}
