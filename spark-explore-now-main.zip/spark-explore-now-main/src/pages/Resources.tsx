import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, ExternalLink, Sparkles } from "lucide-react";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { RichFooter } from "@/components/RichFooter";
import { tools, toolCategories, type Tool, type ToolCategory } from "@/data/tools";
import { Link } from "react-router-dom";

function ToolCard({ tool, index }: { tool: Tool; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.03, ease: [0.2, 0.8, 0.2, 1] }}
    >
      <a
        href={tool.websiteUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="group block rounded-xl border border-border bg-card p-5 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200"
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-secondary/80 flex items-center justify-center text-base">
              {toolCategories.find((c) => c.slug === tool.category)?.icon || "🔧"}
            </div>
            <h3 className="font-medium text-foreground group-hover:text-primary transition-colors text-sm">
              {tool.name}
            </h3>
          </div>
          <ExternalLink className="w-3.5 h-3.5 text-muted-foreground/40 group-hover:text-muted-foreground transition-colors flex-shrink-0 mt-1" />
        </div>
        <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">{tool.description}</p>
        <div className="flex flex-wrap gap-1.5 mt-3">
          {tool.tags.slice(0, 2).map((tag) => (
            <span key={tag} className="text-[10px] px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
              {tag}
            </span>
          ))}
        </div>
      </a>
    </motion.div>
  );
}

export default function ResourcesPage() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<ToolCategory | "all">("all");

  const allTools = activeCategory === "calculators"
    ? []
    : tools.filter((t) => {
        const matchSearch = t.name.toLowerCase().includes(search.toLowerCase()) || t.description.toLowerCase().includes(search.toLowerCase());
        const matchCat = activeCategory === "all" || t.category === activeCategory;
        return matchSearch && matchCat;
      });

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <motion.div
        className="container py-12 md:py-16"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4 }}
      >
        <motion.h1
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="font-editorial text-4xl md:text-5xl font-medium text-foreground mb-3"
        >
          Tools & Resources
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-lg text-muted-foreground mb-8 max-w-2xl"
        >
          A curated selection of the best tools, apps, and platforms worth exploring across every category.
        </motion.p>

        {/* Search */}
        <div className="relative max-w-md mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search tools..."
            className="w-full h-10 pl-10 pr-4 rounded-lg border border-input bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        {/* Category filters */}
        <div className="flex flex-wrap gap-2 mb-8">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-3 py-1.5 text-sm rounded-full border transition-colors ${activeCategory === "all" ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground hover:bg-secondary/60"}`}
          >
            All ({tools.length})
          </button>
          {toolCategories.map((cat) => {
            if (cat.slug === "calculators") {
              return (
                <Link
                  key={cat.slug}
                  to="/calculators"
                  className="px-3 py-1.5 text-sm rounded-full border border-border text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors inline-flex items-center gap-1.5"
                >
                  {cat.icon} {cat.name}
                </Link>
              );
            }
            const count = tools.filter((t) => t.category === cat.slug).length;
            return (
              <button
                key={cat.slug}
                onClick={() => setActiveCategory(cat.slug)}
                className={`px-3 py-1.5 text-sm rounded-full border transition-colors ${activeCategory === cat.slug ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground hover:bg-secondary/60"}`}
              >
                {cat.icon} {cat.name} ({count})
              </button>
            );
          })}
        </div>

        {/* Featured tools banner when showing "all" */}
        {activeCategory === "all" && !search && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.15 }}
            className="mb-8"
          >
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-4 h-4 text-primary" />
              <h2 className="text-sm font-medium text-foreground uppercase tracking-wider">Featured</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-10">
              {tools.filter((t) => t.featured).map((tool, i) => (
                <ToolCard key={tool.id} tool={tool} index={i} />
              ))}
            </div>
            <div className="border-t border-border pt-8">
              <h2 className="text-sm font-medium text-foreground uppercase tracking-wider mb-4">All Tools</h2>
            </div>
          </motion.div>
        )}

        {/* Tools grid */}
        {allTools.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            <AnimatePresence mode="popLayout">
              {(activeCategory === "all" && !search ? allTools.filter((t) => !t.featured) : allTools).map((tool, i) => (
                <ToolCard key={tool.id} tool={tool} index={i} />
              ))}
            </AnimatePresence>
          </div>
        ) : activeCategory !== "calculators" ? (
          <div className="text-center py-16">
            <p className="text-muted-foreground">No tools found matching your search.</p>
          </div>
        ) : null}
      </motion.div>

      <RichFooter />
    </div>
  );
}
