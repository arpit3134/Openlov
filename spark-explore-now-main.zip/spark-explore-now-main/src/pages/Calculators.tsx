import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search } from "lucide-react";
import { StickyHeader } from "@/components/StickyHeader";
import { RichFooter } from "@/components/RichFooter";
import { CalculatorCard } from "@/components/calculator/CalculatorCard";
import { calculators, calcCategories } from "@/data/calculators";

const Calculators = () => {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  const filtered = calculators.filter((c) => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) || c.description.toLowerCase().includes(search.toLowerCase());
    const matchCat = activeCategory === "all" || c.category === activeCategory;
    return matchSearch && matchCat;
  });

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader />
      <motion.div className="container py-12 md:py-16" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }}>
        <motion.h1 initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="font-editorial text-4xl md:text-5xl font-medium text-foreground mb-3">Calculators</motion.h1>
        <motion.p initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }} className="text-lg text-muted-foreground mb-8 max-w-2xl">
          Free online calculators for finance, health, math, development, and more — all running locally, no data sent anywhere.
        </motion.p>

        <div className="relative max-w-md mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search calculators..."
            className="w-full h-10 pl-10 pr-4 rounded-lg border border-input bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div className="flex flex-wrap gap-2 mb-8">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-3 py-1.5 text-sm rounded-full border transition-colors ${activeCategory === "all" ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground hover:bg-secondary/60"}`}
          >
            All ({calculators.length})
          </button>
          {calcCategories.map((cat) => {
            const count = calculators.filter((c) => c.category === cat.slug).length;
            return (
              <button
                key={cat.slug}
                onClick={() => setActiveCategory(cat.slug)}
                className={`px-3 py-1.5 text-sm rounded-full border transition-colors ${activeCategory === cat.slug ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground hover:bg-secondary/60"}`}
              >
                {cat.name} ({count})
              </button>
            );
          })}
        </div>

        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            <AnimatePresence mode="popLayout">
              {filtered.map((calc, i) => (
                <CalculatorCard key={calc.id} calculator={calc} index={i} />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-muted-foreground">No calculators found matching your search.</p>
          </div>
        )}
      </motion.div>
      <RichFooter />
    </div>
  );
};

export default Calculators;
