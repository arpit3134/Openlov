import { useState } from "react";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { RichFooter } from "@/components/RichFooter";

export default function ContactPage() {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <section className="pt-16 pb-20">
        <div className="container max-w-xl">
          <h1 className="font-editorial text-4xl font-medium text-foreground mb-2">Get in touch</h1>
          <p className="text-muted-foreground mb-10">Have a question, suggestion, or want to submit content? We'd love to hear from you.</p>

          <form onSubmit={(e) => e.preventDefault()} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Name</label>
              <input type="text" className="w-full h-11 px-4 rounded-lg bg-secondary border-0 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/20" placeholder="Your name" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Email</label>
              <input type="email" className="w-full h-11 px-4 rounded-lg bg-secondary border-0 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/20" placeholder="you@example.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Message</label>
              <textarea rows={5} className="w-full px-4 py-3 rounded-lg bg-secondary border-0 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/20 resize-none" placeholder="Your message…" />
            </div>
            <button type="submit" className="px-8 py-3 rounded-full bg-foreground text-background text-sm font-medium hover:bg-foreground/90 transition-colors">
              Send message
            </button>
          </form>
        </div>
      </section>

      <RichFooter />
    </div>
  );
}
