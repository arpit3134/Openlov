import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { EditorialCard } from "@/components/EditorialCard";
import { RichFooter } from "@/components/RichFooter";
import { TopicChip } from "@/components/TopicChip";
import { articles } from "@/data/mockData";
import { Share2, Clock, Calendar } from "lucide-react";
import { BookmarkButton } from "@/components/BookmarkButton";

export default function ArticleDetail() {
  const { slug } = useParams();
  const [searchOpen, setSearchOpen] = useState(false);
  const article = articles.find((a) => a.slug === slug);

  if (!article) {
    return (
      <div className="min-h-screen bg-background">
        <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
        <div className="container py-32 text-center">
          <h1 className="font-editorial text-3xl text-foreground mb-4">Article not found</h1>
          <Link to="/articles" className="text-primary hover:underline">Back to articles</Link>
        </div>
        <RichFooter />
      </div>
    );
  }

  const related = articles.filter((a) => a.topic === article.topic && a.id !== article.id).slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <article>
        <div className="w-full aspect-[21/9] md:aspect-[3/1] overflow-hidden">
          <img src={article.image} alt={article.title} className="w-full h-full object-cover" />
        </div>

        <div className="container max-w-3xl py-10 md:py-14">
          <nav className="flex items-center gap-2 text-xs text-muted-foreground mb-6">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <span>/</span>
            <Link to="/articles" className="hover:text-foreground transition-colors">Articles</Link>
            <span>/</span>
            <span className="text-foreground">{article.title}</span>
          </nav>

          <TopicChip topic={article.topic} clickable className="mb-4" />
          <h1 className="font-editorial text-3xl md:text-4xl lg:text-5xl font-medium text-foreground leading-tight mb-6">
            {article.title}
          </h1>

          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-8 pb-8 border-b border-border/50">
            <span className="font-medium text-foreground">{article.author.name}</span>
            <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{new Date(article.publishedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</span>
            <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{article.readTime} min read</span>
            <div className="ml-auto flex items-center gap-2">
              <BookmarkButton />
              <button className="p-1 hover:bg-secondary rounded-full transition-colors"><Share2 className="w-3.5 h-3.5 text-muted-foreground" /></button>
            </div>
          </div>

          <div className="prose prose-lg max-w-none text-foreground/90 leading-relaxed">
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-6">{article.excerpt}</p>
            <p>This is where the full article content would appear. The reading experience is designed to be clean, spacious, and highly readable with generous line-height and optimal column width for long-form content consumption.</p>
            <p>Signal's article pages prioritize readability above all else. The serif headline draws readers in, while the body text uses a clean sans-serif for comfortable extended reading. Every element — from the topic badge to the metadata bar — is carefully positioned to support the reading flow.</p>
            <p>The editorial experience extends beyond just text. Related content appears at the bottom, encouraging further exploration. Topic tags connect readers to broader themes. And the bookmark feature lets readers save articles for later, building their own personal discovery feed over time.</p>
          </div>

          <div className="flex flex-wrap gap-2 mt-8 pt-8 border-t border-border/50">
            {article.tags.map((tag) => (
              <span key={tag} className="px-3 py-1 rounded-full bg-secondary text-xs text-secondary-foreground">#{tag}</span>
            ))}
          </div>
        </div>
      </article>

      {related.length > 0 && (
        <section className="pb-16">
          <div className="container max-w-3xl">
            <h2 className="font-editorial text-2xl font-medium text-foreground mb-6">Related articles</h2>
            <div className="space-y-6">
              {related.map((a) => (
                <EditorialCard key={a.id} article={a} variant="compact" />
              ))}
            </div>
          </div>
        </section>
      )}

      <RichFooter />
    </div>
  );
}
