import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { RichFooter } from "@/components/RichFooter";
import { TopicChip } from "@/components/TopicChip";
import { resources } from "@/data/mockData";
import { ExternalLink, Share2 } from "lucide-react";
import { BookmarkButton } from "@/components/BookmarkButton";

export default function ResourceDetail() {
  const { slug } = useParams();
  const [searchOpen, setSearchOpen] = useState(false);
  const resource = resources.find((r) => r.slug === slug);

  if (!resource) {
    return (
      <div className="min-h-screen bg-background">
        <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
        <div className="container py-32 text-center">
          <h1 className="font-editorial text-3xl text-foreground mb-4">Resource not found</h1>
          <Link to="/resources" className="text-primary hover:underline">Browse resources</Link>
        </div>
        <RichFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <section className="pt-12 pb-16">
        <div className="container max-w-3xl">
          <nav className="flex items-center gap-2 text-xs text-muted-foreground mb-6">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <span>/</span>
            <Link to="/resources" className="hover:text-foreground transition-colors">Tools</Link>
            <span>/</span>
            <span className="text-foreground">{resource.title}</span>
          </nav>

          <div className="rounded-xl overflow-hidden shadow-card mb-8 aspect-[2/1]">
            <img src={resource.coverImage} alt={resource.title} className="w-full h-full object-cover" />
          </div>

          <div className="flex items-start justify-between mb-4">
            <div>
              <TopicChip topic={resource.topic} clickable className="mb-3" />
              <h1 className="font-editorial text-3xl md:text-4xl font-medium text-foreground">{resource.title}</h1>
            </div>
            <div className="flex items-center gap-2">
              <BookmarkButton />
              <button className="p-1 hover:bg-secondary rounded-full transition-colors"><Share2 className="w-4 h-4 text-muted-foreground" /></button>
            </div>
          </div>

          <p className="text-lg text-muted-foreground mb-6">{resource.shortDescription}</p>

          <a
            href={resource.websiteUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-foreground text-background text-sm font-medium hover:bg-foreground/90 transition-colors mb-8"
          >
            Visit website <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <div className="flex flex-wrap gap-2 pt-6 border-t border-border/50">
            {resource.tags.map((tag) => (
              <span key={tag} className="px-3 py-1 rounded-full bg-secondary text-xs text-secondary-foreground">#{tag}</span>
            ))}
          </div>
        </div>
      </section>

      <RichFooter />
    </div>
  );
}
