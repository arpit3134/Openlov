import { useState } from "react";
import { StickyHeader } from "@/components/StickyHeader";
import { DiscoveryHero } from "@/components/DiscoveryHero";
import { TopicExplorer } from "@/components/TopicExplorer";
import { NewsletterCTA } from "@/components/NewsletterCTA";
import { RichFooter } from "@/components/RichFooter";
import { SearchOverlay } from "@/components/SearchOverlay";

const Index = () => {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <DiscoveryHero />
      <TopicExplorer />
      <NewsletterCTA />
      <RichFooter />
    </div>
  );
};

export default Index;
