import { useState } from "react";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { DiscoveryHero } from "@/components/DiscoveryHero";
import { TopicExplorer } from "@/components/TopicExplorer";
import { RichFooter } from "@/components/RichFooter";

export default function DiscoverPage() {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <DiscoveryHero />
      <TopicExplorer />
      <RichFooter />
    </div>
  );
}
