import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { EditorialCard } from "@/components/EditorialCard";
import { NewsCard } from "@/components/NewsCard";
import { ResourceCard } from "@/components/ResourceCard";
import { RichFooter } from "@/components/RichFooter";
import { articles, news, resources } from "@/data/mockData";
import { Search } from "lucide-react";

export default function SearchResults() {
  const [searchParams] = useSearchParams();
  const [searchOpen, setSearchOpen] = useState(false);
  const query = searchParams.get("q") || "";

  const q = query.toLowerCase();
  const matchedArticles = articles.filter((a) => a.title.toLowerCase().includes(q) || a.excerpt.toLowerCase().includes(q) || a.topic.includes(q));
  const matchedNews = news.filter((n) => n.title.toLowerCase().includes(q) || n.topic.includes(q));
  const matchedResources = resources.filter((r) => r.title.toLowerCase().includes(q) || r.shortDescription.toLowerCase().includes(q) || r.topic.includes(q));

  const totalResults = matchedArticles.length + matchedNews.length + matchedResources.length;

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <section className="pt-12 pb-16">
        <div className="container">
          <div className="flex items-center gap-3 mb-2">
            <Search className="w-5 h-5 text-muted-foreground" />
            <h1 className="font-editorial text-3xl font-medium text-foreground">
              {query ? `Results for "${query}"` : "Search"}
            </h1>
          </div>
          <p className="text-muted-foreground mb-10">{totalResults} results found</p>

          {matchedArticles.length > 0 && (
            <div className="mb-12">
              <h2 className="font-sans text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Articles</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {matchedArticles.map((a) => <EditorialCard key={a.id} article={a} />)}
              </div>
            </div>
          )}

          {matchedNews.length > 0 && (
            <div className="mb-12">
              <h2 className="font-sans text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">News</h2>
              {matchedNews.map((n) => <NewsCard key={n.id} item={n} />)}
            </div>
          )}

          {matchedResources.length > 0 && (
            <div className="mb-12">
              <h2 className="font-sans text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Tools & Resources</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {matchedResources.map((r) => <ResourceCard key={r.id} resource={r} />)}
              </div>
            </div>
          )}

          {totalResults === 0 && query && (
            <div className="text-center py-20">
              <p className="text-lg text-muted-foreground">No results found. Try a different search term.</p>
            </div>
          )}
        </div>
      </section>

      <RichFooter />
    </div>
  );
}
