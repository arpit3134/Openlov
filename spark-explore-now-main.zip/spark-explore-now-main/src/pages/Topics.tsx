import { useState } from "react";
import { Link } from "react-router-dom";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { RichFooter } from "@/components/RichFooter";
import { topics } from "@/data/mockData";

export default function TopicsPage() {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <section className="pt-12 pb-16">
        <div className="container">
          <h1 className="font-editorial text-3xl md:text-4xl font-medium text-foreground mb-2">Topics</h1>
          <p className="text-muted-foreground mb-10">Browse everything by subject</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {topics.map((t) => (
              <Link
                key={t.slug}
                to={`/topics/${t.slug}`}
                className="group flex items-start gap-4 p-6 rounded-xl bg-card shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-0.5"
              >
                <span className="text-3xl">{t.icon}</span>
                <div>
                  <h3 className="font-sans text-base font-semibold text-foreground group-hover:text-primary transition-colors">{t.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{t.description}</p>
                  <span className="text-xs text-muted-foreground mt-2 inline-block">{t.articleCount} articles</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <RichFooter />
    </div>
  );
}
