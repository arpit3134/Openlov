import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { StickyHeader } from "@/components/StickyHeader";
import { SearchOverlay } from "@/components/SearchOverlay";
import { EditorialCard } from "@/components/EditorialCard";
import { NewsCard } from "@/components/NewsCard";
import { ResourceCard } from "@/components/ResourceCard";
import { CollectionCard } from "@/components/CollectionCard";
import { RichFooter } from "@/components/RichFooter";
import { SectionHeader } from "@/components/SectionHeader";
import { topics, articles, news, resources, collections } from "@/data/mockData";

export default function TopicDetail() {
  const { slug } = useParams();
  const [searchOpen, setSearchOpen] = useState(false);
  const topic = topics.find((t) => t.slug === slug);

  if (!topic) {
    return (
      <div className="min-h-screen bg-background">
        <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
        <div className="container py-32 text-center">
          <h1 className="font-editorial text-3xl text-foreground mb-4">Topic not found</h1>
          <Link to="/topics" className="text-primary hover:underline">Browse topics</Link>
        </div>
        <RichFooter />
      </div>
    );
  }

  const topicArticles = articles.filter((a) => a.topic === slug);
  const topicNews = news.filter((n) => n.topic === slug);
  const topicResources = resources.filter((r) => r.topic === slug);
  const topicCollections = collections.filter((c) => c.topic === slug);

  return (
    <div className="min-h-screen bg-background">
      <StickyHeader onSearchOpen={() => setSearchOpen(true)} />
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <section className="pt-12 pb-8">
        <div className="container">
          <nav className="flex items-center gap-2 text-xs text-muted-foreground mb-6">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <span>/</span>
            <Link to="/topics" className="hover:text-foreground transition-colors">Topics</Link>
            <span>/</span>
            <span className="text-foreground">{topic.name}</span>
          </nav>
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl">{topic.icon}</span>
            <h1 className="font-editorial text-3xl md:text-4xl font-medium text-foreground">{topic.name}</h1>
          </div>
          <p className="text-muted-foreground max-w-2xl">{topic.description}</p>
        </div>
      </section>

      {topicArticles.length > 0 && (
        <section className="pb-16">
          <div className="container">
            <SectionHeader title="Articles" />
            {topicArticles[0] && <EditorialCard article={topicArticles[0]} variant="feature" className="mb-6" />}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {topicArticles.slice(1).map((a) => (
                <EditorialCard key={a.id} article={a} />
              ))}
            </div>
          </div>
        </section>
      )}

      {topicNews.length > 0 && (
        <section className="pb-16">
          <div className="container max-w-3xl">
            <SectionHeader title="Latest news" />
            {topicNews.map((n) => <NewsCard key={n.id} item={n} />)}
          </div>
        </section>
      )}

      {topicResources.length > 0 && (
        <section className="pb-16">
          <div className="container">
            <SectionHeader title="Tools & resources" />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {topicResources.map((r) => <ResourceCard key={r.id} resource={r} />)}
            </div>
          </div>
        </section>
      )}

      {topicCollections.length > 0 && (
        <section className="pb-16">
          <div className="container">
            <SectionHeader title="Collections" />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {topicCollections.map((c) => <CollectionCard key={c.id} collection={c} />)}
            </div>
          </div>
        </section>
      )}

      <RichFooter />
    </div>
  );
}
