export interface Topic {
  name: string;
  slug: string;
  description: string;
  icon: string;
  featured: boolean;
  color: string;
  articleCount: number;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  image: string;
  excerpt: string;
  content: string;
  topic: string;
  tags: string[];
  author: Author;
  readTime: number;
  publishedAt: string;
  featured: boolean;
  views: number;
}

export interface Author {
  name: string;
  avatar: string;
}

export interface NewsItem {
  id: string;
  title: string;
  slug: string;
  image: string;
  summary: string;
  source: string;
  externalUrl: string;
  topic: string;
  tags: string[];
  publishedAt: string;
  trending: boolean;
}

export interface Resource {
  id: string;
  title: string;
  slug: string;
  logo: string;
  coverImage: string;
  shortDescription: string;
  fullDescription: string;
  websiteUrl: string;
  topic: string;
  tags: string[];
  featured: boolean;
  recommended: boolean;
  views: number;
  createdAt: string;
}

export interface Collection {
  id: string;
  title: string;
  slug: string;
  description: string;
  coverImage: string;
  topic: string;
  itemCount: number;
  featured: boolean;
}

export interface Tag {
  name: string;
  slug: string;
}
