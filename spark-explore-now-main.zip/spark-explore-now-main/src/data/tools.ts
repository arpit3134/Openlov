export interface Tool {
  id: string;
  name: string;
  slug: string;
  description: string;
  websiteUrl: string;
  category: ToolCategory;
  tags: string[];
  featured?: boolean;
}

export type ToolCategory = "ai" | "developer" | "design" | "productivity" | "finance" | "calculators";

export interface ToolCategoryInfo {
  slug: ToolCategory;
  name: string;
  icon: string;
}

export const toolCategories: ToolCategoryInfo[] = [
  { slug: "ai", name: "AI Tools", icon: "🧠" },
  { slug: "developer", name: "Developer", icon: "💻" },
  { slug: "design", name: "Design", icon: "🎨" },
  { slug: "productivity", name: "Productivity", icon: "⚡" },
  { slug: "finance", name: "Finance", icon: "💰" },
  { slug: "calculators", name: "Calculators", icon: "🔢" },
];

export const tools: Tool[] = [
  // ── AI Tools ──
  { id: "ai-1", name: "ChatGPT", slug: "chatgpt", description: "Conversational AI assistant by OpenAI for writing, coding, analysis, and creative tasks.", websiteUrl: "https://chat.openai.com", category: "ai", tags: ["chatbot", "writing", "coding"], featured: true },
  { id: "ai-2", name: "Claude", slug: "claude", description: "Anthropic's AI assistant built for thoughtful, nuanced conversations and long-form content.", websiteUrl: "https://claude.ai", category: "ai", tags: ["chatbot", "writing", "analysis"], featured: true },
  { id: "ai-3", name: "Midjourney", slug: "midjourney", description: "AI image generation tool that creates stunning visuals from text prompts.", websiteUrl: "https://midjourney.com", category: "ai", tags: ["image-generation", "art", "creative"] },
  { id: "ai-4", name: "Perplexity", slug: "perplexity", description: "AI-powered search engine that provides sourced answers to complex questions.", websiteUrl: "https://perplexity.ai", category: "ai", tags: ["search", "research", "answers"], featured: true },
  { id: "ai-5", name: "Runway", slug: "runway", description: "AI-powered creative tools for video generation, editing, and visual effects.", websiteUrl: "https://runwayml.com", category: "ai", tags: ["video", "creative", "editing"] },
  { id: "ai-6", name: "ElevenLabs", slug: "elevenlabs", description: "Realistic AI voice generation and text-to-speech synthesis platform.", websiteUrl: "https://elevenlabs.io", category: "ai", tags: ["voice", "tts", "audio"] },
  { id: "ai-7", name: "Cursor", slug: "cursor", description: "AI-first code editor that helps you write, edit, and understand code faster.", websiteUrl: "https://cursor.sh", category: "ai", tags: ["coding", "editor", "dev-tools"], featured: true },
  { id: "ai-8", name: "Lovable", slug: "lovable", description: "AI-powered full-stack app builder that generates production-ready web applications.", websiteUrl: "https://lovable.dev", category: "ai", tags: ["app-builder", "no-code", "web-dev"], featured: true },
  { id: "ai-9", name: "NotebookLM", slug: "notebooklm", description: "Google's AI research assistant that analyzes your documents and sources.", websiteUrl: "https://notebooklm.google", category: "ai", tags: ["research", "notes", "analysis"] },
  { id: "ai-10", name: "Suno", slug: "suno", description: "AI music generation platform that creates full songs from text prompts.", websiteUrl: "https://suno.com", category: "ai", tags: ["music", "audio", "creative"] },
  { id: "ai-11", name: "Gamma", slug: "gamma", description: "AI-powered presentation and document builder with beautiful templates.", websiteUrl: "https://gamma.app", category: "ai", tags: ["presentations", "documents", "design"] },
  { id: "ai-12", name: "Jasper", slug: "jasper", description: "AI marketing copilot for generating brand-consistent content at scale.", websiteUrl: "https://jasper.ai", category: "ai", tags: ["marketing", "copywriting", "content"] },

  // ── Developer Tools ──
  { id: "dev-1", name: "GitHub", slug: "github", description: "The world's leading platform for code hosting, collaboration, and version control.", websiteUrl: "https://github.com", category: "developer", tags: ["git", "collaboration", "open-source"], featured: true },
  { id: "dev-2", name: "Vercel", slug: "vercel", description: "Frontend cloud platform for deploying and scaling web applications instantly.", websiteUrl: "https://vercel.com", category: "developer", tags: ["hosting", "deployment", "frontend"], featured: true },
  { id: "dev-3", name: "Supabase", slug: "supabase", description: "Open-source Firebase alternative with Postgres database, auth, and real-time features.", websiteUrl: "https://supabase.com", category: "developer", tags: ["database", "backend", "auth"], featured: true },
  { id: "dev-4", name: "Railway", slug: "railway", description: "Deploy and manage infrastructure with zero configuration and instant provisioning.", websiteUrl: "https://railway.app", category: "developer", tags: ["hosting", "deployment", "infrastructure"] },
  { id: "dev-5", name: "Postman", slug: "postman", description: "API platform for building, testing, and documenting APIs collaboratively.", websiteUrl: "https://postman.com", category: "developer", tags: ["api", "testing", "documentation"] },
  { id: "dev-6", name: "Netlify", slug: "netlify", description: "Web development platform for building, deploying, and scaling modern web projects.", websiteUrl: "https://netlify.com", category: "developer", tags: ["hosting", "deployment", "jamstack"] },
  { id: "dev-7", name: "Docker", slug: "docker", description: "Container platform for building, sharing, and running applications consistently.", websiteUrl: "https://docker.com", category: "developer", tags: ["containers", "devops", "infrastructure"] },
  { id: "dev-8", name: "Sentry", slug: "sentry", description: "Application monitoring and error tracking for developers to fix issues fast.", websiteUrl: "https://sentry.io", category: "developer", tags: ["monitoring", "debugging", "errors"] },
  { id: "dev-9", name: "PlanetScale", slug: "planetscale", description: "Serverless MySQL-compatible database platform with branching and zero-downtime schema changes.", websiteUrl: "https://planetscale.com", category: "developer", tags: ["database", "mysql", "serverless"] },
  { id: "dev-10", name: "Resend", slug: "resend", description: "Modern email API for developers with beautiful templates and reliable delivery.", websiteUrl: "https://resend.com", category: "developer", tags: ["email", "api", "communication"] },

  // ── Design Tools ──
  { id: "des-1", name: "Figma", slug: "figma", description: "Collaborative interface design tool for building products together in real time.", websiteUrl: "https://figma.com", category: "design", tags: ["ui-design", "collaboration", "prototyping"], featured: true },
  { id: "des-2", name: "Framer", slug: "framer", description: "Design and publish stunning websites with no-code, animations, and CMS built in.", websiteUrl: "https://framer.com", category: "design", tags: ["website-builder", "animation", "no-code"], featured: true },
  { id: "des-3", name: "Spline", slug: "spline", description: "3D design tool for creating interactive experiences directly in the browser.", websiteUrl: "https://spline.design", category: "design", tags: ["3d", "interactive", "web"] },
  { id: "des-4", name: "Rive", slug: "rive", description: "Create and ship interactive animations for any platform with a powerful editor.", websiteUrl: "https://rive.app", category: "design", tags: ["animation", "interactive", "motion"] },
  { id: "des-5", name: "Mobbin", slug: "mobbin", description: "Curated library of mobile and web design patterns from top apps for inspiration.", websiteUrl: "https://mobbin.com", category: "design", tags: ["inspiration", "patterns", "reference"] },
  { id: "des-6", name: "Coolors", slug: "coolors", description: "Fast color palette generator to find the perfect color schemes for your projects.", websiteUrl: "https://coolors.co", category: "design", tags: ["colors", "palette", "generator"] },
  { id: "des-7", name: "Font Ninja", slug: "font-ninja", description: "Identify fonts on any website and get font pairing suggestions instantly.", websiteUrl: "https://www.fonts.ninja", category: "design", tags: ["typography", "fonts", "browser-extension"] },
  { id: "des-8", name: "Lottie", slug: "lottie", description: "Lightweight animation format for adding high-quality motion to apps and websites.", websiteUrl: "https://lottiefiles.com", category: "design", tags: ["animation", "motion", "assets"] },
  { id: "des-9", name: "Canva", slug: "canva", description: "Visual design platform for creating social media graphics, presentations, and marketing materials.", websiteUrl: "https://canva.com", category: "design", tags: ["graphics", "social-media", "templates"], featured: true },
  { id: "des-10", name: "Excalidraw", slug: "excalidraw", description: "Virtual whiteboard for sketching hand-drawn-like diagrams collaboratively.", websiteUrl: "https://excalidraw.com", category: "design", tags: ["whiteboard", "diagrams", "collaboration"] },

  // ── Productivity Tools ──
  { id: "prod-1", name: "Notion", slug: "notion", description: "All-in-one workspace for notes, docs, wikis, and project management.", websiteUrl: "https://notion.so", category: "productivity", tags: ["notes", "workspace", "project-management"], featured: true },
  { id: "prod-2", name: "Linear", slug: "linear", description: "Streamlined issue tracking and project management built for modern software teams.", websiteUrl: "https://linear.app", category: "productivity", tags: ["project-management", "issue-tracking", "teams"], featured: true },
  { id: "prod-3", name: "Obsidian", slug: "obsidian", description: "Private knowledge base and note-taking app with powerful linking and local-first storage.", websiteUrl: "https://obsidian.md", category: "productivity", tags: ["notes", "knowledge-base", "markdown"] },
  { id: "prod-4", name: "Raycast", slug: "raycast", description: "Blazingly fast productivity launcher for macOS with extensions and workflow automation.", websiteUrl: "https://raycast.com", category: "productivity", tags: ["launcher", "automation", "macos"], featured: true },
  { id: "prod-5", name: "Todoist", slug: "todoist", description: "Task management app that helps organize work and life with projects, labels, and priorities.", websiteUrl: "https://todoist.com", category: "productivity", tags: ["tasks", "to-do", "organization"] },
  { id: "prod-6", name: "Slack", slug: "slack", description: "Messaging platform for teams with channels, integrations, and workflow tools.", websiteUrl: "https://slack.com", category: "productivity", tags: ["messaging", "communication", "teams"] },
  { id: "prod-7", name: "Cron Calendar", slug: "cron", description: "Next-generation calendar app with powerful scheduling and time management features.", websiteUrl: "https://cron.com", category: "productivity", tags: ["calendar", "scheduling", "time-management"] },
  { id: "prod-8", name: "Readwise", slug: "readwise", description: "Save and revisit highlights from books, articles, and podcasts with spaced repetition.", websiteUrl: "https://readwise.io", category: "productivity", tags: ["reading", "highlights", "learning"] },
  { id: "prod-9", name: "Loom", slug: "loom", description: "Record quick videos to share with your team and replace unnecessary meetings.", websiteUrl: "https://loom.com", category: "productivity", tags: ["video", "async", "communication"] },
  { id: "prod-10", name: "1Password", slug: "1password", description: "Secure password manager for teams and individuals with vault sharing and SSO.", websiteUrl: "https://1password.com", category: "productivity", tags: ["passwords", "security", "teams"] },

  // ── Finance Tools ──
  { id: "fin-1", name: "Stripe", slug: "stripe", description: "Financial infrastructure and payment processing platform for internet businesses.", websiteUrl: "https://stripe.com", category: "finance", tags: ["payments", "fintech", "api"], featured: true },
  { id: "fin-2", name: "Wise", slug: "wise", description: "International money transfers with real exchange rates and low transparent fees.", websiteUrl: "https://wise.com", category: "finance", tags: ["transfers", "international", "banking"] },
  { id: "fin-3", name: "Mercury", slug: "mercury", description: "Banking platform designed for startups with powerful financial workflows and integrations.", websiteUrl: "https://mercury.com", category: "finance", tags: ["banking", "startups", "business"], featured: true },
  { id: "fin-4", name: "Brex", slug: "brex", description: "Corporate card and spend management platform built for growing companies.", websiteUrl: "https://brex.com", category: "finance", tags: ["corporate-card", "expense", "startups"] },
  { id: "fin-5", name: "Ramp", slug: "ramp", description: "Corporate card and expense management that helps companies save money automatically.", websiteUrl: "https://ramp.com", category: "finance", tags: ["expense", "corporate-card", "savings"] },
  { id: "fin-6", name: "QuickBooks", slug: "quickbooks", description: "Accounting software for small businesses with invoicing, payroll, and tax features.", websiteUrl: "https://quickbooks.intuit.com", category: "finance", tags: ["accounting", "invoicing", "tax"] },
  { id: "fin-7", name: "Deel", slug: "deel", description: "Global payroll and compliance platform for hiring and paying international teams.", websiteUrl: "https://deel.com", category: "finance", tags: ["payroll", "global", "compliance"] },
  { id: "fin-8", name: "Plaid", slug: "plaid", description: "Financial data connectivity platform that powers fintech apps with bank account access.", websiteUrl: "https://plaid.com", category: "finance", tags: ["api", "banking-data", "fintech"] },
];
