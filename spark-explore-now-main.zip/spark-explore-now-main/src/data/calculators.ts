export interface CalcInput {
  key: string;
  label: string;
  type: 'number' | 'select' | 'text' | 'textarea' | 'date';
  default?: any;
  placeholder?: string;
  suffix?: string;
  prefix?: string;
  min?: number;
  max?: number;
  step?: number;
  options?: { label: string; value: string }[];
}

export interface CalcResult {
  label: string;
  value: string;
  highlight?: boolean;
  type?: 'text' | 'code';
}

export interface Calculator {
  id: string;
  name: string;
  slug: string;
  description: string;
  category: string;
  inputs: CalcInput[];
  calculate: (values: Record<string, any>) => CalcResult[];
}

export interface CalcCategory {
  name: string;
  slug: string;
}

// Helpers
const cur = (n: number) => isNaN(n) || !isFinite(n) ? '—' : '₹' + Math.round(n).toLocaleString('en-IN');
const num = (n: number, d = 2) => isNaN(n) || !isFinite(n) ? '—' : parseFloat(n.toFixed(d)).toLocaleString('en-IN', { maximumFractionDigits: d });
const pct = (n: number) => isNaN(n) || !isFinite(n) ? '—' : n.toFixed(2) + '%';

export const calcCategories: CalcCategory[] = [
  { name: 'Finance', slug: 'finance' },
  { name: 'Tax & Salary', slug: 'tax-salary' },
  { name: 'Health', slug: 'health' },
  { name: 'Date & Time', slug: 'date-time' },
  { name: 'Math & Utility', slug: 'math-utility' },
  { name: 'Developer', slug: 'developer' },
];

const emiCalc = (v: Record<string, any>): CalcResult[] => {
  const p = +v.principal, r = +v.rate / 1200, n = +v.tenure * 12;
  if (!p || !n) return [{ label: 'Monthly EMI', value: '—', highlight: true }];
  const emi = r > 0 ? p * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1) : p / n;
  return [
    { label: 'Monthly EMI', value: cur(emi), highlight: true },
    { label: 'Total Interest', value: cur(emi * n - p) },
    { label: 'Total Amount', value: cur(emi * n) },
  ];
};

const emiInputs = (dp: number, dr: number, dt: number): CalcInput[] => [
  { key: 'principal', label: 'Loan Amount (₹)', type: 'number', default: dp, min: 0 },
  { key: 'rate', label: 'Interest Rate (% p.a.)', type: 'number', default: dr, step: 0.1, min: 0 },
  { key: 'tenure', label: 'Tenure (Years)', type: 'number', default: dt, min: 1 },
];

export const calculators: Calculator[] = [
  // ─── FINANCE ───
  { id: 'emi', name: 'EMI Calculator', slug: 'emi-calculator', description: 'Calculate equated monthly installments for any loan', category: 'finance', inputs: emiInputs(1000000, 10, 5), calculate: emiCalc },
  { id: 'home-loan-emi', name: 'Home Loan EMI Calculator', slug: 'home-loan-emi-calculator', description: 'Plan your home loan with monthly EMI estimates', category: 'finance', inputs: emiInputs(5000000, 8.5, 20), calculate: emiCalc },
  { id: 'car-loan-emi', name: 'Car Loan EMI Calculator', slug: 'car-loan-emi-calculator', description: 'Calculate monthly payments for your car loan', category: 'finance', inputs: emiInputs(800000, 9.5, 5), calculate: emiCalc },
  { id: 'personal-loan-emi', name: 'Personal Loan EMI Calculator', slug: 'personal-loan-emi-calculator', description: 'Estimate EMI for personal loans', category: 'finance', inputs: emiInputs(500000, 14, 3), calculate: emiCalc },
  {
    id: 'sip', name: 'SIP Calculator', slug: 'sip-calculator',
    description: 'Estimate returns on systematic investment plans',
    category: 'finance',
    inputs: [
      { key: 'monthly', label: 'Monthly Investment (₹)', type: 'number', default: 5000, min: 0 },
      { key: 'rate', label: 'Expected Return (% p.a.)', type: 'number', default: 12, step: 0.1 },
      { key: 'years', label: 'Investment Period (Years)', type: 'number', default: 10, min: 1 },
    ],
    calculate: (v) => {
      const p = +v.monthly, r = +v.rate / 1200, n = +v.years * 12;
      if (!p || !n) return [];
      const fv = r > 0 ? p * ((Math.pow(1 + r, n) - 1) / r) * (1 + r) : p * n;
      return [
        { label: 'Total Value', value: cur(fv), highlight: true },
        { label: 'Invested Amount', value: cur(p * n) },
        { label: 'Wealth Gained', value: cur(fv - p * n) },
      ];
    },
  },
  {
    id: 'lumpsum', name: 'Lumpsum Calculator', slug: 'lumpsum-calculator',
    description: 'Calculate returns on a one-time investment',
    category: 'finance',
    inputs: [
      { key: 'principal', label: 'Investment Amount (₹)', type: 'number', default: 100000 },
      { key: 'rate', label: 'Expected Return (% p.a.)', type: 'number', default: 12, step: 0.1 },
      { key: 'years', label: 'Period (Years)', type: 'number', default: 5, min: 1 },
    ],
    calculate: (v) => {
      const p = +v.principal, r = +v.rate / 100, n = +v.years;
      const fv = p * Math.pow(1 + r, n);
      return [
        { label: 'Future Value', value: cur(fv), highlight: true },
        { label: 'Total Returns', value: cur(fv - p) },
        { label: 'Invested Amount', value: cur(p) },
      ];
    },
  },
  {
    id: 'fd', name: 'FD Calculator', slug: 'fd-calculator',
    description: 'Calculate fixed deposit maturity amount',
    category: 'finance',
    inputs: [
      { key: 'principal', label: 'Deposit Amount (₹)', type: 'number', default: 100000 },
      { key: 'rate', label: 'Interest Rate (% p.a.)', type: 'number', default: 7, step: 0.1 },
      { key: 'years', label: 'Tenure (Years)', type: 'number', default: 5, min: 1 },
      { key: 'compound', label: 'Compounding', type: 'select', default: '4', options: [{ label: 'Monthly', value: '12' }, { label: 'Quarterly', value: '4' }, { label: 'Half-Yearly', value: '2' }, { label: 'Yearly', value: '1' }] },
    ],
    calculate: (v) => {
      const p = +v.principal, r = +v.rate / 100, t = +v.years, n = +v.compound;
      const maturity = p * Math.pow(1 + r / n, n * t);
      return [
        { label: 'Maturity Amount', value: cur(maturity), highlight: true },
        { label: 'Total Interest', value: cur(maturity - p) },
        { label: 'Principal', value: cur(p) },
      ];
    },
  },
  {
    id: 'rd', name: 'RD Calculator', slug: 'rd-calculator',
    description: 'Calculate recurring deposit maturity amount',
    category: 'finance',
    inputs: [
      { key: 'monthly', label: 'Monthly Deposit (₹)', type: 'number', default: 5000 },
      { key: 'rate', label: 'Interest Rate (% p.a.)', type: 'number', default: 7, step: 0.1 },
      { key: 'years', label: 'Tenure (Years)', type: 'number', default: 5, min: 1 },
    ],
    calculate: (v) => {
      const p = +v.monthly, r = +v.rate / 400, n = +v.years * 4;
      let maturity = 0;
      for (let i = 1; i <= +v.years * 12; i++) {
        const quarters = (+v.years * 12 - i + 1) / 3;
        maturity += p * Math.pow(1 + r, quarters);
      }
      const invested = p * +v.years * 12;
      return [
        { label: 'Maturity Amount', value: cur(maturity), highlight: true },
        { label: 'Total Interest', value: cur(maturity - invested) },
        { label: 'Invested Amount', value: cur(invested) },
      ];
    },
  },
  {
    id: 'simple-interest', name: 'Simple Interest Calculator', slug: 'simple-interest-calculator',
    description: 'Calculate simple interest on any amount',
    category: 'finance',
    inputs: [
      { key: 'principal', label: 'Principal (₹)', type: 'number', default: 100000 },
      { key: 'rate', label: 'Rate (% p.a.)', type: 'number', default: 8, step: 0.1 },
      { key: 'years', label: 'Time (Years)', type: 'number', default: 3 },
    ],
    calculate: (v) => {
      const si = +v.principal * +v.rate * +v.years / 100;
      return [
        { label: 'Simple Interest', value: cur(si), highlight: true },
        { label: 'Total Amount', value: cur(+v.principal + si) },
      ];
    },
  },
  {
    id: 'compound-interest', name: 'Compound Interest Calculator', slug: 'compound-interest-calculator',
    description: 'Calculate compound interest with flexible compounding',
    category: 'finance',
    inputs: [
      { key: 'principal', label: 'Principal (₹)', type: 'number', default: 100000 },
      { key: 'rate', label: 'Rate (% p.a.)', type: 'number', default: 8, step: 0.1 },
      { key: 'years', label: 'Time (Years)', type: 'number', default: 5 },
      { key: 'n', label: 'Compounding Frequency', type: 'select', default: '12', options: [{ label: 'Monthly', value: '12' }, { label: 'Quarterly', value: '4' }, { label: 'Half-Yearly', value: '2' }, { label: 'Yearly', value: '1' }] },
    ],
    calculate: (v) => {
      const p = +v.principal, r = +v.rate / 100, t = +v.years, n = +v.n;
      const a = p * Math.pow(1 + r / n, n * t);
      return [
        { label: 'Total Amount', value: cur(a), highlight: true },
        { label: 'Compound Interest', value: cur(a - p) },
        { label: 'Principal', value: cur(p) },
      ];
    },
  },
  {
    id: 'cagr', name: 'CAGR Calculator', slug: 'cagr-calculator',
    description: 'Calculate Compound Annual Growth Rate',
    category: 'finance',
    inputs: [
      { key: 'initial', label: 'Initial Value (₹)', type: 'number', default: 100000 },
      { key: 'final', label: 'Final Value (₹)', type: 'number', default: 200000 },
      { key: 'years', label: 'Years', type: 'number', default: 5, min: 1 },
    ],
    calculate: (v) => {
      const cagr = (Math.pow(+v.final / +v.initial, 1 / +v.years) - 1) * 100;
      return [
        { label: 'CAGR', value: pct(cagr), highlight: true },
        { label: 'Absolute Return', value: pct((+v.final - +v.initial) / +v.initial * 100) },
      ];
    },
  },
  {
    id: 'roi', name: 'ROI Calculator', slug: 'roi-calculator',
    description: 'Calculate return on investment',
    category: 'finance',
    inputs: [
      { key: 'invested', label: 'Amount Invested (₹)', type: 'number', default: 100000 },
      { key: 'returned', label: 'Amount Returned (₹)', type: 'number', default: 150000 },
    ],
    calculate: (v) => {
      const roi = ((+v.returned - +v.invested) / +v.invested) * 100;
      return [
        { label: 'ROI', value: pct(roi), highlight: true },
        { label: 'Net Profit', value: cur(+v.returned - +v.invested) },
      ];
    },
  },
  {
    id: 'swp', name: 'SWP Calculator', slug: 'swp-calculator',
    description: 'Plan systematic withdrawals from investments',
    category: 'finance',
    inputs: [
      { key: 'corpus', label: 'Total Investment (₹)', type: 'number', default: 5000000 },
      { key: 'withdrawal', label: 'Monthly Withdrawal (₹)', type: 'number', default: 30000 },
      { key: 'rate', label: 'Expected Return (% p.a.)', type: 'number', default: 8, step: 0.1 },
      { key: 'years', label: 'Period (Years)', type: 'number', default: 10 },
    ],
    calculate: (v) => {
      let balance = +v.corpus;
      const mr = +v.rate / 1200;
      const months = +v.years * 12;
      let totalWithdrawn = 0;
      for (let i = 0; i < months && balance > 0; i++) {
        balance = balance * (1 + mr) - +v.withdrawal;
        totalWithdrawn += +v.withdrawal;
      }
      return [
        { label: 'Remaining Balance', value: cur(Math.max(0, balance)), highlight: true },
        { label: 'Total Withdrawn', value: cur(totalWithdrawn) },
        { label: 'Total Earnings', value: cur(Math.max(0, balance) + totalWithdrawn - +v.corpus) },
      ];
    },
  },
  {
    id: 'ppf', name: 'PPF Calculator', slug: 'ppf-calculator',
    description: 'Calculate Public Provident Fund maturity',
    category: 'finance',
    inputs: [
      { key: 'yearly', label: 'Yearly Deposit (₹)', type: 'number', default: 150000 },
      { key: 'rate', label: 'Interest Rate (% p.a.)', type: 'number', default: 7.1, step: 0.1 },
      { key: 'years', label: 'Tenure (Years)', type: 'number', default: 15, min: 15 },
    ],
    calculate: (v) => {
      let balance = 0;
      const r = +v.rate / 100;
      for (let i = 0; i < +v.years; i++) {
        balance = (balance + +v.yearly) * (1 + r);
      }
      const invested = +v.yearly * +v.years;
      return [
        { label: 'Maturity Amount', value: cur(balance), highlight: true },
        { label: 'Total Interest', value: cur(balance - invested) },
        { label: 'Total Invested', value: cur(invested) },
      ];
    },
  },
  {
    id: 'nps', name: 'NPS Calculator', slug: 'nps-calculator',
    description: 'Estimate your National Pension System corpus',
    category: 'finance',
    inputs: [
      { key: 'monthly', label: 'Monthly Contribution (₹)', type: 'number', default: 5000 },
      { key: 'rate', label: 'Expected Return (% p.a.)', type: 'number', default: 10, step: 0.1 },
      { key: 'age', label: 'Current Age', type: 'number', default: 30 },
      { key: 'retire', label: 'Retirement Age', type: 'number', default: 60 },
    ],
    calculate: (v) => {
      const years = +v.retire - +v.age;
      const p = +v.monthly, r = +v.rate / 1200, n = years * 12;
      if (years <= 0) return [{ label: 'Error', value: 'Retirement age must be greater than current age' }];
      const fv = r > 0 ? p * ((Math.pow(1 + r, n) - 1) / r) * (1 + r) : p * n;
      const invested = p * n;
      const annuity = fv * 0.4;
      const lumpsum = fv * 0.6;
      return [
        { label: 'Total Corpus', value: cur(fv), highlight: true },
        { label: 'Lumpsum (60%)', value: cur(lumpsum) },
        { label: 'Annuity Investment (40%)', value: cur(annuity) },
        { label: 'Total Invested', value: cur(invested) },
      ];
    },
  },
  {
    id: 'retirement', name: 'Retirement Calculator', slug: 'retirement-calculator',
    description: 'Plan how much you need for retirement',
    category: 'finance',
    inputs: [
      { key: 'expense', label: 'Current Monthly Expense (₹)', type: 'number', default: 50000 },
      { key: 'age', label: 'Current Age', type: 'number', default: 30 },
      { key: 'retire', label: 'Retirement Age', type: 'number', default: 60 },
      { key: 'life', label: 'Life Expectancy', type: 'number', default: 80 },
      { key: 'inflation', label: 'Inflation Rate (%)', type: 'number', default: 6, step: 0.1 },
      { key: 'returnRate', label: 'Investment Return (%)', type: 'number', default: 10, step: 0.1 },
    ],
    calculate: (v) => {
      const years = +v.retire - +v.age;
      const retireYears = +v.life - +v.retire;
      if (years <= 0 || retireYears <= 0) return [{ label: 'Error', value: 'Check your age inputs' }];
      const futureExpense = +v.expense * 12 * Math.pow(1 + +v.inflation / 100, years);
      const corpusNeeded = futureExpense * ((1 - Math.pow(1 + (+v.returnRate - +v.inflation) / 100, -retireYears)) / ((+v.returnRate - +v.inflation) / 100));
      const monthlyRate = +v.returnRate / 1200;
      const months = years * 12;
      const monthlySaving = monthlyRate > 0 ? corpusNeeded / (((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate)) : corpusNeeded / months;
      return [
        { label: 'Corpus Needed at Retirement', value: cur(corpusNeeded), highlight: true },
        { label: 'Monthly Saving Required', value: cur(monthlySaving) },
        { label: 'Future Annual Expense', value: cur(futureExpense) },
      ];
    },
  },
  {
    id: 'savings-goal', name: 'Savings Goal Calculator', slug: 'savings-goal-calculator',
    description: 'How much to save monthly to reach a goal',
    category: 'finance',
    inputs: [
      { key: 'goal', label: 'Goal Amount (₹)', type: 'number', default: 1000000 },
      { key: 'years', label: 'Time to Achieve (Years)', type: 'number', default: 5, min: 1 },
      { key: 'rate', label: 'Expected Return (% p.a.)', type: 'number', default: 10, step: 0.1 },
    ],
    calculate: (v) => {
      const r = +v.rate / 1200, n = +v.years * 12;
      const monthly = r > 0 ? +v.goal * r / (Math.pow(1 + r, n) - 1) / (1 + r) : +v.goal / n;
      return [
        { label: 'Monthly Savings Needed', value: cur(monthly), highlight: true },
        { label: 'Total Investment', value: cur(monthly * n) },
        { label: 'Interest Earned', value: cur(+v.goal - monthly * n) },
      ];
    },
  },
  {
    id: 'inflation', name: 'Inflation Calculator', slug: 'inflation-calculator',
    description: 'See how inflation affects purchasing power',
    category: 'finance',
    inputs: [
      { key: 'amount', label: 'Current Amount (₹)', type: 'number', default: 100000 },
      { key: 'rate', label: 'Inflation Rate (%)', type: 'number', default: 6, step: 0.1 },
      { key: 'years', label: 'Years', type: 'number', default: 10 },
    ],
    calculate: (v) => {
      const future = +v.amount * Math.pow(1 + +v.rate / 100, +v.years);
      const purchasing = +v.amount / Math.pow(1 + +v.rate / 100, +v.years);
      return [
        { label: 'Future Cost', value: cur(future), highlight: true },
        { label: 'Purchasing Power of Today\'s Amount', value: cur(purchasing) },
        { label: 'Value Lost to Inflation', value: cur(+v.amount - purchasing) },
      ];
    },
  },
  {
    id: 'loan-eligibility', name: 'Loan Eligibility Calculator', slug: 'loan-eligibility-calculator',
    description: 'Check how much loan you can get based on income',
    category: 'finance',
    inputs: [
      { key: 'income', label: 'Monthly Income (₹)', type: 'number', default: 100000 },
      { key: 'expenses', label: 'Existing EMIs (₹)', type: 'number', default: 10000 },
      { key: 'rate', label: 'Interest Rate (% p.a.)', type: 'number', default: 9, step: 0.1 },
      { key: 'tenure', label: 'Tenure (Years)', type: 'number', default: 20 },
    ],
    calculate: (v) => {
      const maxEmi = (+v.income * 0.5) - +v.expenses;
      if (maxEmi <= 0) return [{ label: 'Eligible Amount', value: 'EMI capacity exceeded' }];
      const r = +v.rate / 1200, n = +v.tenure * 12;
      const eligible = r > 0 ? maxEmi * (Math.pow(1 + r, n) - 1) / (r * Math.pow(1 + r, n)) : maxEmi * n;
      return [
        { label: 'Maximum Loan Amount', value: cur(eligible), highlight: true },
        { label: 'Affordable EMI', value: cur(maxEmi) },
      ];
    },
  },
  {
    id: 'down-payment', name: 'Down Payment Calculator', slug: 'down-payment-calculator',
    description: 'Calculate the down payment needed',
    category: 'finance',
    inputs: [
      { key: 'price', label: 'Property/Asset Price (₹)', type: 'number', default: 5000000 },
      { key: 'percent', label: 'Down Payment (%)', type: 'number', default: 20, step: 1 },
    ],
    calculate: (v) => {
      const dp = +v.price * +v.percent / 100;
      return [
        { label: 'Down Payment', value: cur(dp), highlight: true },
        { label: 'Loan Amount', value: cur(+v.price - dp) },
      ];
    },
  },

  // ─── TAX & SALARY ───
  {
    id: 'income-tax', name: 'Income Tax Calculator', slug: 'income-tax-calculator',
    description: 'Estimate your income tax under the new regime',
    category: 'tax-salary',
    inputs: [
      { key: 'income', label: 'Annual Income (₹)', type: 'number', default: 1200000 },
      { key: 'deductions', label: 'Standard Deduction (₹)', type: 'number', default: 75000 },
    ],
    calculate: (v) => {
      const taxable = Math.max(0, +v.income - +v.deductions);
      const slabs = [
        { limit: 300000, rate: 0 },
        { limit: 700000, rate: 0.05 },
        { limit: 1000000, rate: 0.10 },
        { limit: 1200000, rate: 0.15 },
        { limit: 1500000, rate: 0.20 },
        { limit: Infinity, rate: 0.30 },
      ];
      let tax = 0, prev = 0;
      for (const slab of slabs) {
        const slabIncome = Math.min(taxable, slab.limit) - prev;
        if (slabIncome > 0) tax += slabIncome * slab.rate;
        prev = slab.limit;
        if (taxable <= slab.limit) break;
      }
      const cess = tax * 0.04;
      return [
        { label: 'Total Tax', value: cur(tax + cess), highlight: true },
        { label: 'Tax (before cess)', value: cur(tax) },
        { label: 'Health & Education Cess (4%)', value: cur(cess) },
        { label: 'Taxable Income', value: cur(taxable) },
        { label: 'Effective Tax Rate', value: pct((tax + cess) / +v.income * 100) },
      ];
    },
  },
  {
    id: 'gst', name: 'GST Calculator', slug: 'gst-calculator',
    description: 'Calculate GST on any amount',
    category: 'tax-salary',
    inputs: [
      { key: 'amount', label: 'Amount (₹)', type: 'number', default: 10000 },
      { key: 'rate', label: 'GST Rate', type: 'select', default: '18', options: [{ label: '5%', value: '5' }, { label: '12%', value: '12' }, { label: '18%', value: '18' }, { label: '28%', value: '28' }] },
      { key: 'type', label: 'Calculation Type', type: 'select', default: 'exclusive', options: [{ label: 'GST Exclusive (add GST)', value: 'exclusive' }, { label: 'GST Inclusive (extract GST)', value: 'inclusive' }] },
    ],
    calculate: (v) => {
      const r = +v.rate / 100;
      if (v.type === 'inclusive') {
        const base = +v.amount / (1 + r);
        const gst = +v.amount - base;
        return [
          { label: 'Base Price', value: cur(base), highlight: true },
          { label: 'GST Amount', value: cur(gst) },
          { label: 'CGST', value: cur(gst / 2) },
          { label: 'SGST', value: cur(gst / 2) },
        ];
      }
      const gst = +v.amount * r;
      return [
        { label: 'Total Price', value: cur(+v.amount + gst), highlight: true },
        { label: 'GST Amount', value: cur(gst) },
        { label: 'CGST', value: cur(gst / 2) },
        { label: 'SGST', value: cur(gst / 2) },
      ];
    },
  },
  {
    id: 'salary', name: 'Salary Calculator', slug: 'salary-calculator',
    description: 'Convert between monthly and annual salary',
    category: 'tax-salary',
    inputs: [
      { key: 'ctc', label: 'Annual CTC (₹)', type: 'number', default: 1200000 },
      { key: 'bonus', label: 'Annual Bonus (₹)', type: 'number', default: 100000 },
    ],
    calculate: (v) => {
      const monthly = (+v.ctc - +v.bonus) / 12;
      const monthlyBonus = +v.bonus / 12;
      return [
        { label: 'Monthly Salary (excl. bonus)', value: cur(monthly), highlight: true },
        { label: 'Monthly (incl. bonus)', value: cur(monthly + monthlyBonus) },
        { label: 'Daily Rate (260 working days)', value: cur(+v.ctc / 260) },
        { label: 'Hourly Rate (2080 hrs)', value: cur(+v.ctc / 2080) },
      ];
    },
  },
  {
    id: 'inhand-salary', name: 'In-hand Salary Calculator', slug: 'inhand-salary-calculator',
    description: 'Estimate take-home salary from CTC',
    category: 'tax-salary',
    inputs: [
      { key: 'ctc', label: 'Annual CTC (₹)', type: 'number', default: 1200000 },
      { key: 'pf', label: 'Employee PF (%)', type: 'number', default: 12 },
      { key: 'pt', label: 'Professional Tax (₹/month)', type: 'number', default: 200 },
      { key: 'tax', label: 'Monthly Income Tax (₹)', type: 'number', default: 5000 },
    ],
    calculate: (v) => {
      const monthly = +v.ctc / 12;
      const pfAmount = monthly * +v.pf / 100;
      const inhand = monthly - pfAmount - +v.pt - +v.tax;
      return [
        { label: 'Monthly In-hand', value: cur(inhand), highlight: true },
        { label: 'Gross Monthly', value: cur(monthly) },
        { label: 'PF Deduction', value: cur(pfAmount) },
        { label: 'Total Deductions', value: cur(pfAmount + +v.pt + +v.tax) },
        { label: 'Annual In-hand', value: cur(inhand * 12) },
      ];
    },
  },
  {
    id: 'hra', name: 'HRA Calculator', slug: 'hra-calculator',
    description: 'Calculate HRA exemption for tax savings',
    category: 'tax-salary',
    inputs: [
      { key: 'basic', label: 'Basic Salary (₹/month)', type: 'number', default: 50000 },
      { key: 'hra', label: 'HRA Received (₹/month)', type: 'number', default: 20000 },
      { key: 'rent', label: 'Rent Paid (₹/month)', type: 'number', default: 25000 },
      { key: 'metro', label: 'Metro City?', type: 'select', default: 'yes', options: [{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }] },
    ],
    calculate: (v) => {
      const basicAnnual = +v.basic * 12;
      const hraReceived = +v.hra * 12;
      const rentPaid = +v.rent * 12;
      const pctBasic = v.metro === 'yes' ? 0.5 : 0.4;
      const exempt = Math.min(hraReceived, pctBasic * basicAnnual, rentPaid - 0.1 * basicAnnual);
      return [
        { label: 'HRA Exemption (Annual)', value: cur(Math.max(0, exempt)), highlight: true },
        { label: 'Taxable HRA', value: cur(hraReceived - Math.max(0, exempt)) },
      ];
    },
  },

  // ─── HEALTH ───
  {
    id: 'bmi', name: 'BMI Calculator', slug: 'bmi-calculator',
    description: 'Calculate your Body Mass Index',
    category: 'health',
    inputs: [
      { key: 'weight', label: 'Weight (kg)', type: 'number', default: 70, step: 0.1 },
      { key: 'height', label: 'Height (cm)', type: 'number', default: 170 },
    ],
    calculate: (v) => {
      const h = +v.height / 100;
      const bmi = +v.weight / (h * h);
      let category = 'Normal';
      if (bmi < 18.5) category = 'Underweight';
      else if (bmi < 25) category = 'Normal';
      else if (bmi < 30) category = 'Overweight';
      else category = 'Obese';
      return [
        { label: 'BMI', value: num(bmi, 1), highlight: true },
        { label: 'Category', value: category },
        { label: 'Healthy Range', value: '18.5 — 24.9' },
      ];
    },
  },
  {
    id: 'bmr', name: 'BMR Calculator', slug: 'bmr-calculator',
    description: 'Calculate your Basal Metabolic Rate',
    category: 'health',
    inputs: [
      { key: 'weight', label: 'Weight (kg)', type: 'number', default: 70, step: 0.1 },
      { key: 'height', label: 'Height (cm)', type: 'number', default: 170 },
      { key: 'age', label: 'Age', type: 'number', default: 30 },
      { key: 'gender', label: 'Gender', type: 'select', default: 'male', options: [{ label: 'Male', value: 'male' }, { label: 'Female', value: 'female' }] },
    ],
    calculate: (v) => {
      const bmr = v.gender === 'male'
        ? 10 * +v.weight + 6.25 * +v.height - 5 * +v.age + 5
        : 10 * +v.weight + 6.25 * +v.height - 5 * +v.age - 161;
      return [
        { label: 'BMR', value: num(bmr, 0) + ' cal/day', highlight: true },
        { label: 'Sedentary (little exercise)', value: num(bmr * 1.2, 0) + ' cal/day' },
        { label: 'Moderate (3-5 days/week)', value: num(bmr * 1.55, 0) + ' cal/day' },
        { label: 'Active (6-7 days/week)', value: num(bmr * 1.725, 0) + ' cal/day' },
      ];
    },
  },
  {
    id: 'calorie', name: 'Calorie Calculator', slug: 'calorie-calculator',
    description: 'Calculate daily calorie needs',
    category: 'health',
    inputs: [
      { key: 'weight', label: 'Weight (kg)', type: 'number', default: 70, step: 0.1 },
      { key: 'height', label: 'Height (cm)', type: 'number', default: 170 },
      { key: 'age', label: 'Age', type: 'number', default: 30 },
      { key: 'gender', label: 'Gender', type: 'select', default: 'male', options: [{ label: 'Male', value: 'male' }, { label: 'Female', value: 'female' }] },
      { key: 'activity', label: 'Activity Level', type: 'select', default: '1.55', options: [{ label: 'Sedentary', value: '1.2' }, { label: 'Light (1-3 days/week)', value: '1.375' }, { label: 'Moderate (3-5 days/week)', value: '1.55' }, { label: 'Active (6-7 days/week)', value: '1.725' }] },
    ],
    calculate: (v) => {
      const bmr = v.gender === 'male'
        ? 10 * +v.weight + 6.25 * +v.height - 5 * +v.age + 5
        : 10 * +v.weight + 6.25 * +v.height - 5 * +v.age - 161;
      const tdee = bmr * +v.activity;
      return [
        { label: 'Maintenance Calories', value: num(tdee, 0) + ' cal/day', highlight: true },
        { label: 'Weight Loss (-500 cal)', value: num(tdee - 500, 0) + ' cal/day' },
        { label: 'Weight Gain (+500 cal)', value: num(tdee + 500, 0) + ' cal/day' },
        { label: 'BMR', value: num(bmr, 0) + ' cal/day' },
      ];
    },
  },
  {
    id: 'water-intake', name: 'Water Intake Calculator', slug: 'water-intake-calculator',
    description: 'How much water should you drink daily',
    category: 'health',
    inputs: [
      { key: 'weight', label: 'Weight (kg)', type: 'number', default: 70, step: 0.1 },
      { key: 'activity', label: 'Activity Level', type: 'select', default: 'moderate', options: [{ label: 'Sedentary', value: 'sedentary' }, { label: 'Moderate', value: 'moderate' }, { label: 'Active', value: 'active' }] },
    ],
    calculate: (v) => {
      const base = +v.weight * 0.033;
      const multiplier = v.activity === 'active' ? 1.3 : v.activity === 'moderate' ? 1.15 : 1;
      const liters = base * multiplier;
      return [
        { label: 'Daily Water Intake', value: num(liters, 1) + ' liters', highlight: true },
        { label: 'Glasses (250ml)', value: num(liters * 4, 0) + ' glasses' },
      ];
    },
  },
  {
    id: 'ideal-weight', name: 'Ideal Weight Calculator', slug: 'ideal-weight-calculator',
    description: 'Find your ideal body weight range',
    category: 'health',
    inputs: [
      { key: 'height', label: 'Height (cm)', type: 'number', default: 170 },
      { key: 'gender', label: 'Gender', type: 'select', default: 'male', options: [{ label: 'Male', value: 'male' }, { label: 'Female', value: 'female' }] },
    ],
    calculate: (v) => {
      const h = +v.height;
      const hm = h / 100;
      const bmiLow = 18.5 * hm * hm;
      const bmiHigh = 24.9 * hm * hm;
      const devine = v.gender === 'male' ? 50 + 2.3 * ((h / 2.54) - 60) : 45.5 + 2.3 * ((h / 2.54) - 60);
      return [
        { label: 'Ideal Weight (Devine)', value: num(devine, 1) + ' kg', highlight: true },
        { label: 'BMI Healthy Range', value: num(bmiLow, 1) + ' — ' + num(bmiHigh, 1) + ' kg' },
      ];
    },
  },
  {
    id: 'pregnancy-due-date', name: 'Pregnancy Due Date Calculator', slug: 'pregnancy-due-date-calculator',
    description: 'Estimate your due date from LMP',
    category: 'health',
    inputs: [
      { key: 'lmp', label: 'Last Menstrual Period', type: 'date', default: '' },
    ],
    calculate: (v) => {
      if (!v.lmp) return [{ label: 'Due Date', value: 'Enter your LMP date' }];
      const lmp = new Date(v.lmp);
      if (isNaN(lmp.getTime())) return [{ label: 'Due Date', value: 'Invalid date' }];
      const due = new Date(lmp.getTime() + 280 * 86400000);
      const today = new Date();
      const weeksPregnant = Math.floor((today.getTime() - lmp.getTime()) / (7 * 86400000));
      const trimester = weeksPregnant < 13 ? 'First' : weeksPregnant < 27 ? 'Second' : 'Third';
      return [
        { label: 'Estimated Due Date', value: due.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }), highlight: true },
        { label: 'Current Week', value: weeksPregnant > 0 ? 'Week ' + weeksPregnant : 'Not started' },
        { label: 'Trimester', value: trimester },
      ];
    },
  },

  // ─── DATE & TIME ───
  {
    id: 'age', name: 'Age Calculator', slug: 'age-calculator',
    description: 'Calculate exact age from date of birth',
    category: 'date-time',
    inputs: [
      { key: 'dob', label: 'Date of Birth', type: 'date', default: '' },
    ],
    calculate: (v) => {
      if (!v.dob) return [{ label: 'Age', value: 'Enter your date of birth' }];
      const birth = new Date(v.dob);
      const now = new Date();
      if (isNaN(birth.getTime())) return [{ label: 'Age', value: 'Invalid date' }];
      let years = now.getFullYear() - birth.getFullYear();
      let months = now.getMonth() - birth.getMonth();
      let days = now.getDate() - birth.getDate();
      if (days < 0) { months--; days += new Date(now.getFullYear(), now.getMonth(), 0).getDate(); }
      if (months < 0) { years--; months += 12; }
      const totalDays = Math.floor((now.getTime() - birth.getTime()) / 86400000);
      return [
        { label: 'Age', value: `${years} years, ${months} months, ${days} days`, highlight: true },
        { label: 'Total Days', value: totalDays.toLocaleString() },
        { label: 'Total Weeks', value: Math.floor(totalDays / 7).toLocaleString() },
        { label: 'Total Months', value: (years * 12 + months).toString() },
      ];
    },
  },
  {
    id: 'date-difference', name: 'Date Difference Calculator', slug: 'date-difference-calculator',
    description: 'Find the difference between two dates',
    category: 'date-time',
    inputs: [
      { key: 'from', label: 'From Date', type: 'date', default: '' },
      { key: 'to', label: 'To Date', type: 'date', default: '' },
    ],
    calculate: (v) => {
      if (!v.from || !v.to) return [{ label: 'Difference', value: 'Enter both dates' }];
      const from = new Date(v.from), to = new Date(v.to);
      const diff = Math.abs(to.getTime() - from.getTime());
      const days = Math.floor(diff / 86400000);
      const weeks = Math.floor(days / 7);
      const months = Math.floor(days / 30.44);
      const years = Math.floor(days / 365.25);
      return [
        { label: 'Total Days', value: days.toLocaleString(), highlight: true },
        { label: 'Weeks', value: weeks.toLocaleString() },
        { label: 'Months (approx)', value: months.toString() },
        { label: 'Years (approx)', value: years.toString() },
      ];
    },
  },
  {
    id: 'days-between', name: 'Days Between Dates Calculator', slug: 'days-between-dates-calculator',
    description: 'Count business and calendar days between dates',
    category: 'date-time',
    inputs: [
      { key: 'from', label: 'Start Date', type: 'date', default: '' },
      { key: 'to', label: 'End Date', type: 'date', default: '' },
    ],
    calculate: (v) => {
      if (!v.from || !v.to) return [{ label: 'Days', value: 'Enter both dates' }];
      const from = new Date(v.from), to = new Date(v.to);
      const totalDays = Math.floor(Math.abs(to.getTime() - from.getTime()) / 86400000);
      let businessDays = 0;
      const start = new Date(Math.min(from.getTime(), to.getTime()));
      for (let i = 0; i < totalDays; i++) {
        const d = new Date(start.getTime() + i * 86400000);
        if (d.getDay() !== 0 && d.getDay() !== 6) businessDays++;
      }
      return [
        { label: 'Calendar Days', value: totalDays.toLocaleString(), highlight: true },
        { label: 'Business Days', value: businessDays.toLocaleString() },
        { label: 'Weekends', value: (totalDays - businessDays).toLocaleString() },
        { label: 'Weeks', value: Math.floor(totalDays / 7).toString() },
      ];
    },
  },
  {
    id: 'time-difference', name: 'Time Difference Calculator', slug: 'time-difference-calculator',
    description: 'Calculate difference between two times',
    category: 'date-time',
    inputs: [
      { key: 'from', label: 'Start Time (HH:MM)', type: 'text', default: '09:00', placeholder: 'e.g. 09:00' },
      { key: 'to', label: 'End Time (HH:MM)', type: 'text', default: '17:30', placeholder: 'e.g. 17:30' },
    ],
    calculate: (v) => {
      const parse = (t: string) => { const [h, m] = t.split(':').map(Number); return h * 60 + (m || 0); };
      const fromMin = parse(v.from), toMin = parse(v.to);
      if (isNaN(fromMin) || isNaN(toMin)) return [{ label: 'Difference', value: 'Enter valid times' }];
      let diff = toMin - fromMin;
      if (diff < 0) diff += 24 * 60;
      return [
        { label: 'Difference', value: `${Math.floor(diff / 60)}h ${diff % 60}m`, highlight: true },
        { label: 'Total Minutes', value: diff.toString() },
        { label: 'Decimal Hours', value: num(diff / 60, 2) },
      ];
    },
  },
  {
    id: 'countdown', name: 'Countdown Calculator', slug: 'countdown-calculator',
    description: 'Count days until a target date',
    category: 'date-time',
    inputs: [
      { key: 'target', label: 'Target Date', type: 'date', default: '' },
    ],
    calculate: (v) => {
      if (!v.target) return [{ label: 'Days', value: 'Enter a target date' }];
      const target = new Date(v.target);
      const now = new Date();
      const diff = target.getTime() - now.getTime();
      const days = Math.ceil(diff / 86400000);
      const weeks = Math.floor(days / 7);
      const hours = Math.floor(diff / 3600000);
      return [
        { label: days >= 0 ? 'Days Remaining' : 'Days Ago', value: Math.abs(days).toLocaleString(), highlight: true },
        { label: 'Weeks', value: Math.abs(weeks).toLocaleString() },
        { label: 'Hours', value: Math.abs(hours).toLocaleString() },
      ];
    },
  },

  // ─── MATH & UTILITY ───
  {
    id: 'percentage', name: 'Percentage Calculator', slug: 'percentage-calculator',
    description: 'Calculate percentages easily',
    category: 'math-utility',
    inputs: [
      { key: 'value', label: 'Value', type: 'number', default: 500 },
      { key: 'percentage', label: 'Percentage (%)', type: 'number', default: 20 },
    ],
    calculate: (v) => {
      const result = +v.value * +v.percentage / 100;
      return [
        { label: `${v.percentage}% of ${v.value}`, value: num(result), highlight: true },
        { label: `${v.value} is what % of`, value: num(+v.value / +v.percentage * 100) },
        { label: 'Increase by %', value: num(+v.value + result) },
        { label: 'Decrease by %', value: num(+v.value - result) },
      ];
    },
  },
  {
    id: 'discount', name: 'Discount Calculator', slug: 'discount-calculator',
    description: 'Calculate discounted price and savings',
    category: 'math-utility',
    inputs: [
      { key: 'price', label: 'Original Price (₹)', type: 'number', default: 1000 },
      { key: 'discount', label: 'Discount (%)', type: 'number', default: 25 },
    ],
    calculate: (v) => {
      const savings = +v.price * +v.discount / 100;
      return [
        { label: 'Discounted Price', value: cur(+v.price - savings), highlight: true },
        { label: 'You Save', value: cur(savings) },
      ];
    },
  },
  {
    id: 'ratio', name: 'Ratio Calculator', slug: 'ratio-calculator',
    description: 'Simplify and solve ratios',
    category: 'math-utility',
    inputs: [
      { key: 'a', label: 'Value A', type: 'number', default: 12 },
      { key: 'b', label: 'Value B', type: 'number', default: 18 },
    ],
    calculate: (v) => {
      const gcd = (a: number, b: number): number => b === 0 ? a : gcd(b, a % b);
      const g = gcd(Math.abs(+v.a), Math.abs(+v.b));
      return [
        { label: 'Simplified Ratio', value: `${+v.a / g} : ${+v.b / g}`, highlight: true },
        { label: 'Decimal', value: num(+v.a / +v.b) },
        { label: 'Percentage', value: pct(+v.a / +v.b * 100) },
      ];
    },
  },
  {
    id: 'average', name: 'Average Calculator', slug: 'average-calculator',
    description: 'Calculate mean, median and more from a list of numbers',
    category: 'math-utility',
    inputs: [
      { key: 'numbers', label: 'Numbers (comma-separated)', type: 'text', default: '10, 20, 30, 40, 50', placeholder: 'e.g. 10, 20, 30' },
    ],
    calculate: (v) => {
      const nums = String(v.numbers).split(',').map(s => parseFloat(s.trim())).filter(n => !isNaN(n));
      if (!nums.length) return [{ label: 'Average', value: 'Enter numbers' }];
      const sum = nums.reduce((a, b) => a + b, 0);
      const mean = sum / nums.length;
      const sorted = [...nums].sort((a, b) => a - b);
      const median = sorted.length % 2 ? sorted[Math.floor(sorted.length / 2)] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2;
      return [
        { label: 'Mean', value: num(mean), highlight: true },
        { label: 'Median', value: num(median) },
        { label: 'Sum', value: num(sum) },
        { label: 'Count', value: nums.length.toString() },
        { label: 'Min / Max', value: `${num(sorted[0])} / ${num(sorted[sorted.length - 1])}` },
      ];
    },
  },
  {
    id: 'scientific', name: 'Scientific Calculator', slug: 'scientific-calculator',
    description: 'Perform scientific math operations',
    category: 'math-utility',
    inputs: [
      { key: 'value', label: 'Value', type: 'number', default: 144 },
      { key: 'op', label: 'Operation', type: 'select', default: 'sqrt', options: [{ label: 'Square Root', value: 'sqrt' }, { label: 'Square', value: 'sq' }, { label: 'Cube', value: 'cube' }, { label: 'Log₁₀', value: 'log10' }, { label: 'Natural Log', value: 'ln' }, { label: 'Factorial', value: 'fact' }, { label: 'Sin', value: 'sin' }, { label: 'Cos', value: 'cos' }, { label: 'Tan', value: 'tan' }] },
    ],
    calculate: (v) => {
      const x = +v.value;
      const ops: Record<string, () => number> = {
        sqrt: () => Math.sqrt(x), sq: () => x * x, cube: () => x * x * x,
        log10: () => Math.log10(x), ln: () => Math.log(x),
        fact: () => { let r = 1; for (let i = 2; i <= Math.min(x, 170); i++) r *= i; return r; },
        sin: () => Math.sin(x * Math.PI / 180), cos: () => Math.cos(x * Math.PI / 180), tan: () => Math.tan(x * Math.PI / 180),
      };
      const result = ops[v.op]?.() ?? 0;
      return [{ label: 'Result', value: num(result, 6), highlight: true }];
    },
  },
  {
    id: 'fraction', name: 'Fraction Calculator', slug: 'fraction-calculator',
    description: 'Simplify fractions',
    category: 'math-utility',
    inputs: [
      { key: 'num', label: 'Numerator', type: 'number', default: 24 },
      { key: 'den', label: 'Denominator', type: 'number', default: 36 },
    ],
    calculate: (v) => {
      const gcd = (a: number, b: number): number => b === 0 ? a : gcd(b, a % b);
      const n = +v.num, d = +v.den;
      if (d === 0) return [{ label: 'Error', value: 'Cannot divide by zero' }];
      const g = gcd(Math.abs(n), Math.abs(d));
      return [
        { label: 'Simplified', value: `${n / g}/${d / g}`, highlight: true },
        { label: 'Decimal', value: num(n / d, 6) },
        { label: 'Percentage', value: pct(n / d * 100) },
      ];
    },
  },
  {
    id: 'decimal-to-fraction', name: 'Decimal to Fraction Calculator', slug: 'decimal-to-fraction-calculator',
    description: 'Convert decimals to fractions',
    category: 'math-utility',
    inputs: [
      { key: 'decimal', label: 'Decimal', type: 'number', default: 0.375, step: 0.001 },
    ],
    calculate: (v) => {
      const dec = +v.decimal;
      const precision = 1000000;
      const gcd = (a: number, b: number): number => b === 0 ? a : gcd(b, a % b);
      const n = Math.round(dec * precision);
      const g = gcd(Math.abs(n), precision);
      return [
        { label: 'Fraction', value: `${n / g}/${precision / g}`, highlight: true },
        { label: 'Percentage', value: pct(dec * 100) },
      ];
    },
  },
  {
    id: 'square-cube', name: 'Square & Cube Calculator', slug: 'square-cube-calculator',
    description: 'Calculate squares, cubes, and their roots',
    category: 'math-utility',
    inputs: [
      { key: 'value', label: 'Number', type: 'number', default: 9 },
    ],
    calculate: (v) => {
      const x = +v.value;
      return [
        { label: 'Square', value: num(x * x), highlight: true },
        { label: 'Cube', value: num(x * x * x) },
        { label: 'Square Root', value: num(Math.sqrt(x), 4) },
        { label: 'Cube Root', value: num(Math.cbrt(x), 4) },
      ];
    },
  },
  {
    id: 'profit-loss', name: 'Profit & Loss Calculator', slug: 'profit-loss-calculator',
    description: 'Calculate profit, loss and margins',
    category: 'math-utility',
    inputs: [
      { key: 'cp', label: 'Cost Price (₹)', type: 'number', default: 800 },
      { key: 'sp', label: 'Selling Price (₹)', type: 'number', default: 1000 },
    ],
    calculate: (v) => {
      const cp = +v.cp, sp = +v.sp;
      const diff = sp - cp;
      const margin = (diff / sp) * 100;
      const markup = (diff / cp) * 100;
      return [
        { label: diff >= 0 ? 'Profit' : 'Loss', value: cur(Math.abs(diff)), highlight: true },
        { label: diff >= 0 ? 'Profit %' : 'Loss %', value: pct(Math.abs(markup)) },
        { label: 'Margin %', value: pct(Math.abs(margin)) },
      ];
    },
  },
  {
    id: 'unit-converter', name: 'Unit Converter', slug: 'unit-converter',
    description: 'Convert between common units',
    category: 'math-utility',
    inputs: [
      { key: 'value', label: 'Value', type: 'number', default: 100 },
      { key: 'type', label: 'Conversion Type', type: 'select', default: 'km-mi', options: [{ label: 'km → miles', value: 'km-mi' }, { label: 'miles → km', value: 'mi-km' }, { label: 'kg → lbs', value: 'kg-lb' }, { label: 'lbs → kg', value: 'lb-kg' }, { label: '°C → °F', value: 'c-f' }, { label: '°F → °C', value: 'f-c' }, { label: 'cm → inches', value: 'cm-in' }, { label: 'inches → cm', value: 'in-cm' }] },
    ],
    calculate: (v) => {
      const x = +v.value;
      const conversions: Record<string, [number | ((n: number) => number), string]> = {
        'km-mi': [0.621371, 'miles'],
        'mi-km': [1.60934, 'km'],
        'kg-lb': [2.20462, 'lbs'],
        'lb-kg': [0.453592, 'kg'],
        'c-f': [(n: number) => n * 9 / 5 + 32, '°F'],
        'f-c': [(n: number) => (n - 32) * 5 / 9, '°C'],
        'cm-in': [0.393701, 'inches'],
        'in-cm': [2.54, 'cm'],
      };
      const [factor, unit] = conversions[v.type] || [1, ''];
      const result = typeof factor === 'function' ? factor(x) : x * factor;
      return [{ label: 'Result', value: `${num(result, 4)} ${unit}`, highlight: true }];
    },
  },
  {
    id: 'tip', name: 'Tip Calculator', slug: 'tip-calculator',
    description: 'Calculate tip amount and total',
    category: 'math-utility',
    inputs: [
      { key: 'bill', label: 'Bill Amount (₹)', type: 'number', default: 1500 },
      { key: 'tip', label: 'Tip (%)', type: 'number', default: 15 },
      { key: 'people', label: 'Split Between', type: 'number', default: 1, min: 1 },
    ],
    calculate: (v) => {
      const tip = +v.bill * +v.tip / 100;
      const total = +v.bill + tip;
      const perPerson = total / Math.max(1, +v.people);
      return [
        { label: 'Tip Amount', value: cur(tip), highlight: true },
        { label: 'Total', value: cur(total) },
        { label: 'Per Person', value: cur(perPerson) },
      ];
    },
  },
  {
    id: 'split-bill', name: 'Split Bill Calculator', slug: 'split-bill-calculator',
    description: 'Split a bill equally among people',
    category: 'math-utility',
    inputs: [
      { key: 'total', label: 'Total Bill (₹)', type: 'number', default: 3000 },
      { key: 'people', label: 'Number of People', type: 'number', default: 4, min: 1 },
      { key: 'tip', label: 'Tip (%)', type: 'number', default: 10 },
    ],
    calculate: (v) => {
      const tip = +v.total * +v.tip / 100;
      const grandTotal = +v.total + tip;
      const perPerson = grandTotal / Math.max(1, +v.people);
      return [
        { label: 'Per Person', value: cur(perPerson), highlight: true },
        { label: 'Tip Total', value: cur(tip) },
        { label: 'Grand Total', value: cur(grandTotal) },
      ];
    },
  },
  {
    id: 'fuel-cost', name: 'Fuel Cost Calculator', slug: 'fuel-cost-calculator',
    description: 'Calculate fuel cost for a trip',
    category: 'math-utility',
    inputs: [
      { key: 'distance', label: 'Distance (km)', type: 'number', default: 500 },
      { key: 'mileage', label: 'Mileage (km/L)', type: 'number', default: 15 },
      { key: 'price', label: 'Fuel Price (₹/L)', type: 'number', default: 105 },
    ],
    calculate: (v) => {
      const fuel = +v.distance / +v.mileage;
      const cost = fuel * +v.price;
      return [
        { label: 'Total Fuel Cost', value: cur(cost), highlight: true },
        { label: 'Fuel Required', value: num(fuel, 1) + ' liters' },
        { label: 'Cost per km', value: cur(cost / +v.distance) },
      ];
    },
  },
  {
    id: 'mileage', name: 'Mileage Calculator', slug: 'mileage-calculator',
    description: 'Calculate vehicle fuel efficiency',
    category: 'math-utility',
    inputs: [
      { key: 'distance', label: 'Distance Traveled (km)', type: 'number', default: 400 },
      { key: 'fuel', label: 'Fuel Used (liters)', type: 'number', default: 30 },
    ],
    calculate: (v) => {
      const mileage = +v.distance / +v.fuel;
      return [
        { label: 'Mileage', value: num(mileage, 1) + ' km/L', highlight: true },
        { label: 'Fuel per 100 km', value: num(+v.fuel / +v.distance * 100, 1) + ' L' },
      ];
    },
  },
  {
    id: 'electricity-bill', name: 'Electricity Bill Calculator', slug: 'electricity-bill-calculator',
    description: 'Estimate your electricity bill',
    category: 'math-utility',
    inputs: [
      { key: 'units', label: 'Units Consumed (kWh)', type: 'number', default: 300 },
      { key: 'rate', label: 'Rate per Unit (₹)', type: 'number', default: 8 },
      { key: 'fixed', label: 'Fixed Charges (₹)', type: 'number', default: 100 },
    ],
    calculate: (v) => {
      const energy = +v.units * +v.rate;
      const total = energy + +v.fixed;
      return [
        { label: 'Total Bill', value: cur(total), highlight: true },
        { label: 'Energy Charges', value: cur(energy) },
        { label: 'Fixed Charges', value: cur(+v.fixed) },
      ];
    },
  },

  // ─── DEVELOPER ───
  {
    id: 'json-formatter', name: 'JSON Formatter', slug: 'json-formatter',
    description: 'Format and beautify JSON data',
    category: 'developer',
    inputs: [{ key: 'input', label: 'JSON Input', type: 'textarea', default: '{"name":"Signal","version":1,"features":["search","discover"]}', placeholder: 'Paste JSON here...' }],
    calculate: (v) => {
      try {
        return [{ label: 'Formatted JSON', value: JSON.stringify(JSON.parse(v.input), null, 2), type: 'code' }];
      } catch (e) {
        return [{ label: 'Error', value: 'Invalid JSON: ' + (e as Error).message }];
      }
    },
  },
  {
    id: 'json-validator', name: 'JSON Validator', slug: 'json-validator',
    description: 'Validate JSON syntax',
    category: 'developer',
    inputs: [{ key: 'input', label: 'JSON Input', type: 'textarea', default: '{"valid": true}', placeholder: 'Paste JSON to validate...' }],
    calculate: (v) => {
      try {
        JSON.parse(v.input);
        return [{ label: 'Status', value: '✓ Valid JSON', highlight: true }];
      } catch (e) {
        return [{ label: 'Status', value: '✗ Invalid — ' + (e as Error).message }];
      }
    },
  },
  {
    id: 'base64', name: 'Base64 Encode/Decode', slug: 'base64-encode-decode',
    description: 'Encode or decode Base64 strings',
    category: 'developer',
    inputs: [
      { key: 'input', label: 'Input', type: 'textarea', default: 'Hello, Signal!', placeholder: 'Enter text...' },
      { key: 'mode', label: 'Mode', type: 'select', default: 'encode', options: [{ label: 'Encode', value: 'encode' }, { label: 'Decode', value: 'decode' }] },
    ],
    calculate: (v) => {
      try {
        const result = v.mode === 'encode' ? btoa(unescape(encodeURIComponent(v.input))) : decodeURIComponent(escape(atob(v.input)));
        return [{ label: v.mode === 'encode' ? 'Encoded' : 'Decoded', value: result, type: 'code', highlight: true }];
      } catch {
        return [{ label: 'Error', value: 'Invalid input for ' + v.mode }];
      }
    },
  },
  {
    id: 'url-encoder', name: 'URL Encoder/Decoder', slug: 'url-encoder-decoder',
    description: 'Encode or decode URL components',
    category: 'developer',
    inputs: [
      { key: 'input', label: 'Input', type: 'textarea', default: 'hello world & foo=bar', placeholder: 'Enter text or URL...' },
      { key: 'mode', label: 'Mode', type: 'select', default: 'encode', options: [{ label: 'Encode', value: 'encode' }, { label: 'Decode', value: 'decode' }] },
    ],
    calculate: (v) => {
      try {
        const result = v.mode === 'encode' ? encodeURIComponent(v.input) : decodeURIComponent(v.input);
        return [{ label: v.mode === 'encode' ? 'Encoded' : 'Decoded', value: result, type: 'code', highlight: true }];
      } catch {
        return [{ label: 'Error', value: 'Invalid input' }];
      }
    },
  },
  {
    id: 'regex-tester', name: 'Regex Tester', slug: 'regex-tester',
    description: 'Test regular expressions against text',
    category: 'developer',
    inputs: [
      { key: 'pattern', label: 'Regex Pattern', type: 'text', default: '\\d+', placeholder: 'e.g. \\d+' },
      { key: 'flags', label: 'Flags', type: 'text', default: 'g', placeholder: 'e.g. gi' },
      { key: 'text', label: 'Test String', type: 'textarea', default: 'There are 42 apples and 7 oranges', placeholder: 'Enter test string...' },
    ],
    calculate: (v) => {
      try {
        const re = new RegExp(v.pattern, v.flags);
        const matches = v.text.match(re);
        return [
          { label: 'Matches Found', value: matches ? matches.length.toString() : '0', highlight: true },
          { label: 'Matches', value: matches ? matches.join(', ') : 'No matches', type: 'code' },
        ];
      } catch (e) {
        return [{ label: 'Error', value: (e as Error).message }];
      }
    },
  },
  {
    id: 'markdown-previewer', name: 'Markdown Previewer', slug: 'markdown-previewer',
    description: 'Preview basic Markdown as HTML',
    category: 'developer',
    inputs: [{ key: 'input', label: 'Markdown', type: 'textarea', default: '# Hello World\n\nThis is **bold** and *italic*.\n\n- Item 1\n- Item 2\n\n[Link](https://example.com)', placeholder: 'Enter markdown...' }],
    calculate: (v) => {
      let html = v.input
        .replace(/^### (.+)$/gm, '<h3>$1</h3>')
        .replace(/^## (.+)$/gm, '<h2>$1</h2>')
        .replace(/^# (.+)$/gm, '<h1>$1</h1>')
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        .replace(/`(.+?)`/g, '<code>$1</code>')
        .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2">$1</a>')
        .replace(/^- (.+)$/gm, '<li>$1</li>')
        .replace(/\n\n/g, '<br/><br/>');
      return [{ label: 'HTML Output', value: html, type: 'code' }];
    },
  },
  {
    id: 'word-counter', name: 'Word Counter', slug: 'word-counter',
    description: 'Count words, characters, sentences and paragraphs',
    category: 'developer',
    inputs: [{ key: 'text', label: 'Text', type: 'textarea', default: 'Signal is a modern discovery platform. It helps you explore articles, tools, and insights.', placeholder: 'Paste text here...' }],
    calculate: (v) => {
      const text = String(v.text);
      const words = text.trim() ? text.trim().split(/\s+/).length : 0;
      const chars = text.length;
      const charsNoSpace = text.replace(/\s/g, '').length;
      const sentences = text.split(/[.!?]+/).filter(s => s.trim()).length;
      const paragraphs = text.split(/\n\n+/).filter(s => s.trim()).length;
      const readTime = Math.max(1, Math.ceil(words / 200));
      return [
        { label: 'Words', value: words.toLocaleString(), highlight: true },
        { label: 'Characters', value: chars.toLocaleString() },
        { label: 'Characters (no spaces)', value: charsNoSpace.toLocaleString() },
        { label: 'Sentences', value: sentences.toString() },
        { label: 'Paragraphs', value: paragraphs.toString() },
        { label: 'Reading Time', value: readTime + ' min' },
      ];
    },
  },
  {
    id: 'character-counter', name: 'Character Counter', slug: 'character-counter',
    description: 'Count characters with detailed breakdown',
    category: 'developer',
    inputs: [{ key: 'text', label: 'Text', type: 'textarea', default: 'Hello, World! 123', placeholder: 'Paste text here...' }],
    calculate: (v) => {
      const t = String(v.text);
      return [
        { label: 'Total Characters', value: t.length.toLocaleString(), highlight: true },
        { label: 'Letters', value: (t.match(/[a-zA-Z]/g) || []).length.toString() },
        { label: 'Digits', value: (t.match(/\d/g) || []).length.toString() },
        { label: 'Spaces', value: (t.match(/ /g) || []).length.toString() },
        { label: 'Special Characters', value: (t.match(/[^a-zA-Z0-9\s]/g) || []).length.toString() },
      ];
    },
  },
  {
    id: 'case-converter', name: 'Case Converter', slug: 'case-converter',
    description: 'Convert text between different cases',
    category: 'developer',
    inputs: [
      { key: 'text', label: 'Input Text', type: 'textarea', default: 'hello world signal platform', placeholder: 'Enter text...' },
    ],
    calculate: (v) => {
      const t = String(v.text);
      return [
        { label: 'UPPERCASE', value: t.toUpperCase(), type: 'code' },
        { label: 'lowercase', value: t.toLowerCase(), type: 'code' },
        { label: 'Title Case', value: t.replace(/\w\S*/g, w => w[0].toUpperCase() + w.slice(1).toLowerCase()), type: 'code' },
        { label: 'Sentence case', value: t.charAt(0).toUpperCase() + t.slice(1).toLowerCase(), type: 'code' },
        { label: 'camelCase', value: t.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, (_, c) => c.toUpperCase()), type: 'code' },
        { label: 'snake_case', value: t.toLowerCase().replace(/\s+/g, '_'), type: 'code' },
      ];
    },
  },
  {
    id: 'slug-generator', name: 'Slug Generator', slug: 'slug-generator',
    description: 'Generate URL-friendly slugs from text',
    category: 'developer',
    inputs: [
      { key: 'text', label: 'Input Text', type: 'text', default: 'Signal — The Modern Discovery Platform!', placeholder: 'Enter title or text...' },
    ],
    calculate: (v) => {
      const slug = String(v.text).toLowerCase().trim()
        .replace(/[^\w\s-]/g, '')
        .replace(/[\s_]+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
      return [
        { label: 'Slug', value: slug, type: 'code', highlight: true },
        { label: 'Character Count', value: slug.length.toString() },
      ];
    },
  },
];
