import { Topic, Article, NewsItem, Resource, Collection } from "./types";

export const topics: Topic[] = [
  { name: "Technology", slug: "technology", description: "The latest in tech innovation and digital transformation", icon: "💻", featured: true, color: "hsl(221, 100%, 50%)", articleCount: 42 },
  { name: "AI & Machine Learning", slug: "ai", description: "Artificial intelligence breakthroughs and applications", icon: "🧠", featured: true, color: "hsl(262, 80%, 55%)", articleCount: 38 },
  { name: "Business", slug: "business", description: "Strategy, leadership, and the future of work", icon: "📈", featured: true, color: "hsl(142, 60%, 40%)", articleCount: 31 },
  { name: "Science", slug: "science", description: "Discoveries pushing the boundaries of human knowledge", icon: "🔬", featured: true, color: "hsl(199, 80%, 48%)", articleCount: 27 },
  { name: "Design", slug: "design", description: "Craft, creativity, and the art of building beautiful things", icon: "🎨", featured: true, color: "hsl(330, 70%, 55%)", articleCount: 24 },
  { name: "Startups", slug: "startups", description: "Building companies from zero to one", icon: "🚀", featured: true, color: "hsl(25, 90%, 55%)", articleCount: 22 },
  { name: "Finance", slug: "finance", description: "Markets, investing, and the future of money", icon: "💰", featured: false, color: "hsl(45, 80%, 50%)", articleCount: 19 },
  { name: "Productivity", slug: "productivity", description: "Systems, habits, and tools that help you do more", icon: "⚡", featured: false, color: "hsl(175, 60%, 42%)", articleCount: 18 },
  { name: "Education", slug: "education", description: "Learning, teaching, and knowledge sharing", icon: "📚", featured: false, color: "hsl(280, 60%, 50%)", articleCount: 15 },
  { name: "Marketing", slug: "marketing", description: "Growth, branding, and reaching your audience", icon: "📣", featured: false, color: "hsl(350, 70%, 52%)", articleCount: 14 },
  { name: "Culture", slug: "culture", description: "Ideas, trends, and the pulse of modern life", icon: "🌍", featured: false, color: "hsl(200, 50%, 45%)", articleCount: 12 },
  { name: "Health", slug: "health", description: "Wellness, biotech, and the science of living better", icon: "🏥", featured: false, color: "hsl(160, 60%, 45%)", articleCount: 11 },
];

const defaultAuthor = { name: "Signal Editorial", avatar: "" };

export const articles: Article[] = [
  {
    id: "1", title: "The Quiet Revolution in How We Search the Internet",
    slug: "quiet-revolution-search", image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80",
    excerpt: "Search is being reinvented from the ground up. Here's what the next decade of information discovery looks like.",
    content: "", topic: "technology", tags: ["search", "ai", "web"], author: defaultAuthor, readTime: 8, publishedAt: "2026-03-14", featured: true, views: 12400,
  },
  {
    id: "2", title: "Why Every Company is Becoming a Data Company",
    slug: "every-company-data", image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80",
    excerpt: "The organizations that win in the next era will be the ones that treat data as their most strategic asset.",
    content: "", topic: "business", tags: ["data", "strategy", "enterprise"], author: { name: "Maya Chen", avatar: "" }, readTime: 6, publishedAt: "2026-03-13", featured: true, views: 8900,
  },
  {
    id: "3", title: "The New Science of Learning: What Research Actually Shows",
    slug: "new-science-learning", image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800&q=80",
    excerpt: "Decades of cognitive science research distilled into principles that actually work for modern learners.",
    content: "", topic: "education", tags: ["learning", "science", "cognitive"], author: { name: "Dr. Sarah Lin", avatar: "" }, readTime: 11, publishedAt: "2026-03-12", featured: true, views: 7200,
  },
  {
    id: "4", title: "Designing for the Age of Ambient Computing",
    slug: "ambient-computing-design", image: "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=800&q=80",
    excerpt: "As technology fades into the background, designers face a fascinating new challenge: designing for invisibility.",
    content: "", topic: "design", tags: ["ux", "ambient", "future"], author: { name: "James Park", avatar: "" }, readTime: 7, publishedAt: "2026-03-11", featured: false, views: 5600,
  },
  {
    id: "5", title: "The Startup Playbook Has Changed — Here's the New One",
    slug: "new-startup-playbook", image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=800&q=80",
    excerpt: "Capital efficiency, AI-native teams, and a fundamentally different approach to building companies in 2026.",
    content: "", topic: "startups", tags: ["startups", "venture", "strategy"], author: { name: "Alex Rivera", avatar: "" }, readTime: 9, publishedAt: "2026-03-10", featured: false, views: 6800,
  },
  {
    id: "6", title: "Understanding Large Language Models Without the Hype",
    slug: "llm-without-hype", image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80",
    excerpt: "A clear-eyed look at what LLMs can and can't do, and why that matters more than ever.",
    content: "", topic: "ai", tags: ["llm", "ai", "research"], author: { name: "Dr. Priya Sharma", avatar: "" }, readTime: 12, publishedAt: "2026-03-09", featured: false, views: 11200,
  },
  {
    id: "7", title: "The Global Race for Quantum Advantage",
    slug: "quantum-advantage-race", image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&q=80",
    excerpt: "Nations and corporations are investing billions in quantum computing. Here's where the race actually stands.",
    content: "", topic: "science", tags: ["quantum", "computing", "research"], author: defaultAuthor, readTime: 10, publishedAt: "2026-03-08", featured: false, views: 4300,
  },
  {
    id: "8", title: "How Smart Budgeting Apps Are Reshaping Personal Finance",
    slug: "smart-budgeting-apps", image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&q=80",
    excerpt: "A new generation of financial tools is making it easier than ever to understand and manage your money.",
    content: "", topic: "finance", tags: ["fintech", "budgeting", "apps"], author: { name: "Rachel Kim", avatar: "" }, readTime: 5, publishedAt: "2026-03-07", featured: false, views: 3200,
  },
  {
    id: "9", title: "The Productivity Myth: Why Doing Less Might Be the Answer",
    slug: "productivity-myth", image: "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=800&q=80",
    excerpt: "Research suggests our obsession with productivity is counterproductive. Here's a better framework.",
    content: "", topic: "productivity", tags: ["productivity", "wellness", "work"], author: { name: "Tom Harris", avatar: "" }, readTime: 7, publishedAt: "2026-03-06", featured: false, views: 5100,
  },
  {
    id: "10", title: "Content Marketing in the Age of AI-Generated Everything",
    slug: "content-marketing-ai-age", image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80",
    excerpt: "When anyone can generate content, authenticity and perspective become the ultimate competitive advantage.",
    content: "", topic: "marketing", tags: ["marketing", "ai", "content"], author: { name: "Lisa Wong", avatar: "" }, readTime: 6, publishedAt: "2026-03-05", featured: false, views: 4700,
  },
];

export const news: NewsItem[] = [
  { id: "n1", title: "OpenAI announces new reasoning model with improved accuracy", slug: "openai-reasoning-model", image: "", summary: "The latest model shows significant improvements in mathematical and logical reasoning tasks.", source: "TechCrunch", externalUrl: "#", topic: "ai", tags: ["openai", "ai"], publishedAt: "2026-03-14", trending: true },
  { id: "n2", title: "European Union finalizes comprehensive data sovereignty framework", slug: "eu-data-sovereignty", image: "", summary: "New regulations will reshape how companies handle user data across EU member states.", source: "Reuters", externalUrl: "#", topic: "technology", tags: ["regulation", "eu"], publishedAt: "2026-03-14", trending: true },
  { id: "n3", title: "SpaceX successfully tests next-generation Raptor engine", slug: "spacex-raptor-test", image: "", summary: "The improved engine design could cut launch costs by another 40%.", source: "Ars Technica", externalUrl: "#", topic: "science", tags: ["space", "engineering"], publishedAt: "2026-03-13", trending: true },
  { id: "n4", title: "Stripe launches embedded finance toolkit for SaaS platforms", slug: "stripe-embedded-finance", image: "", summary: "New APIs allow any SaaS platform to offer banking and lending services.", source: "The Verge", externalUrl: "#", topic: "startups", tags: ["fintech", "api"], publishedAt: "2026-03-13", trending: false },
  { id: "n5", title: "Global EdTech funding reaches new high in Q1 2026", slug: "edtech-funding-q1", image: "", summary: "Investors are pouring capital into AI-powered personalized learning platforms.", source: "Bloomberg", externalUrl: "#", topic: "education", tags: ["edtech", "funding"], publishedAt: "2026-03-12", trending: false },
  { id: "n6", title: "Apple Vision Pro 2 rumored for fall release with lighter design", slug: "vision-pro-2-rumors", image: "", summary: "Reports suggest a 40% weight reduction and improved battery life.", source: "9to5Mac", externalUrl: "#", topic: "technology", tags: ["apple", "ar"], publishedAt: "2026-03-12", trending: true },
];

export const resources: Resource[] = [
  { id: "r1", title: "Linear", slug: "linear", logo: "", coverImage: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&q=80", shortDescription: "Streamline your software projects with modern issue tracking", fullDescription: "", websiteUrl: "https://linear.app", topic: "productivity", tags: ["project-management", "dev-tools"], featured: true, recommended: true, views: 15000, createdAt: "2026-01-15" },
  { id: "r2", title: "Figma", slug: "figma", logo: "", coverImage: "https://images.unsplash.com/photo-1609921212029-bb5a28e60960?w=400&q=80", shortDescription: "The collaborative design tool for building meaningful products", fullDescription: "", websiteUrl: "https://figma.com", topic: "design", tags: ["design", "collaboration"], featured: true, recommended: true, views: 22000, createdAt: "2026-01-10" },
  { id: "r3", title: "Notion", slug: "notion", logo: "", coverImage: "https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=400&q=80", shortDescription: "All-in-one workspace for notes, docs, and project management", fullDescription: "", websiteUrl: "https://notion.so", topic: "productivity", tags: ["notes", "workspace"], featured: true, recommended: true, views: 18000, createdAt: "2026-01-08" },
  { id: "r4", title: "Perplexity", slug: "perplexity", logo: "", coverImage: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&q=80", shortDescription: "AI-powered search engine that understands your questions", fullDescription: "", websiteUrl: "https://perplexity.ai", topic: "ai", tags: ["search", "ai"], featured: true, recommended: true, views: 12000, createdAt: "2026-02-01" },
  { id: "r5", title: "Stripe", slug: "stripe", logo: "", coverImage: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&q=80", shortDescription: "Financial infrastructure for the internet economy", fullDescription: "", websiteUrl: "https://stripe.com", topic: "finance", tags: ["payments", "fintech"], featured: false, recommended: true, views: 20000, createdAt: "2026-01-20" },
  { id: "r6", title: "Vercel", slug: "vercel", logo: "", coverImage: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&q=80", shortDescription: "The platform for frontend developers to build and deploy", fullDescription: "", websiteUrl: "https://vercel.com", topic: "technology", tags: ["hosting", "dev-tools"], featured: false, recommended: true, views: 14000, createdAt: "2026-01-25" },
];

export const collections: Collection[] = [
  { id: "c1", title: "Essential Tools for Modern Teams", slug: "essential-tools-teams", description: "The productivity stack that high-performing teams swear by in 2026.", coverImage: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&q=80", topic: "productivity", itemCount: 12, featured: true },
  { id: "c2", title: "The AI Research Reading List", slug: "ai-research-reading-list", description: "Curated papers and articles for understanding where AI is really heading.", coverImage: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80", topic: "ai", itemCount: 18, featured: true },
  { id: "c3", title: "Design Systems That Scale", slug: "design-systems-scale", description: "How the best product teams build and maintain design consistency.", coverImage: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&q=80", topic: "design", itemCount: 9, featured: true },
  { id: "c4", title: "The Week in Science", slug: "week-in-science", description: "The most important scientific developments from this week, explained clearly.", coverImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80", topic: "science", itemCount: 7, featured: false },
  { id: "c5", title: "Startup Fundraising Essentials", slug: "startup-fundraising", description: "Everything founders need to know about raising capital in the current market.", coverImage: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&q=80", topic: "startups", itemCount: 14, featured: false },
];
