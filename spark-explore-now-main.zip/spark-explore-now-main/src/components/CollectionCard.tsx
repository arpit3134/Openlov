import { Link } from "react-router-dom";
import { Collection } from "@/data/types";
import { cn } from "@/lib/utils";

export function CollectionCard({ collection, className }: { collection: Collection; className?: string }) {
  return (
    <Link to={`/collections/${collection.slug}`} className={cn("group block", className)}>
      <div className="relative overflow-hidden rounded-xl shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-0.5">
        <div className="aspect-[4/3] overflow-hidden">
          <img src={collection.coverImage} alt={collection.title} className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-500" loading="lazy" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/10 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-5">
          <span className="text-[11px] font-medium text-primary-foreground/60 uppercase tracking-wider">{collection.itemCount} items</span>
          <h3 className="font-editorial text-lg font-medium text-primary-foreground leading-snug mt-1 mb-1">{collection.title}</h3>
          <p className="text-xs text-primary-foreground/70 line-clamp-2">{collection.description}</p>
        </div>
      </div>
    </Link>
  );
}
