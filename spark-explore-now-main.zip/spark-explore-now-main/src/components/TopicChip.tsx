import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { topics } from "@/data/mockData";

interface TopicChipProps {
  topic: string;
  size?: "sm" | "md";
  className?: string;
  clickable?: boolean;
}

export function TopicChip({ topic, size = "md", className, clickable = false }: TopicChipProps) {
  const topicData = topics.find((t) => t.slug === topic);
  const label = topicData?.name || topic;

  const chipClass = cn(
    "inline-flex items-center font-sans font-medium rounded-full transition-colors",
    size === "sm" ? "text-[11px] px-2.5 py-0.5" : "text-xs px-3 py-1",
    "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    className
  );

  if (clickable) {
    return <Link to={`/topics/${topic}`} className={chipClass}>{label}</Link>;
  }
  return <span className={chipClass}>{label}</span>;
}
