import { ExternalLink } from "lucide-react";
import { NewsItem } from "@/data/types";
import { TopicChip } from "./TopicChip";
import { cn } from "@/lib/utils";

export function NewsCard({ item, className }: { item: NewsItem; className?: string }) {
  return (
    <a
      href={item.externalUrl}
      target="_blank"
      rel="noopener noreferrer"
      className={cn("group flex items-start gap-4 py-4 border-b border-border/50 last:border-0 hover:bg-secondary/30 -mx-3 px-3 rounded-lg transition-colors", className)}
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1.5">
          <TopicChip topic={item.topic} size="sm" />
          {item.trending && <span className="text-[10px] font-semibold text-primary uppercase tracking-wider">Trending</span>}
        </div>
        <h3 className="text-sm font-medium text-foreground leading-snug group-hover:text-primary transition-colors line-clamp-2 mb-1">
          {item.title}
        </h3>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>{item.source}</span>
          <span>·</span>
          <span>{new Date(item.publishedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
        </div>
      </div>
      <ExternalLink className="w-3.5 h-3.5 text-muted-foreground/40 mt-1 flex-shrink-0 group-hover:text-primary transition-colors" />
    </a>
  );
}
