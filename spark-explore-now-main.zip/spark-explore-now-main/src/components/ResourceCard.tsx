import { Link } from "react-router-dom";
import { ExternalLink } from "lucide-react";
import { Resource } from "@/data/types";
import { TopicChip } from "./TopicChip";
import { cn } from "@/lib/utils";

export function ResourceCard({ resource, className }: { resource: Resource; className?: string }) {
  return (
    <Link to={`/resources/${resource.slug}`} className={cn("group block", className)}>
      <div className="rounded-xl shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-0.5 bg-card overflow-hidden">
        <div className="aspect-[16/10] overflow-hidden">
          <img src={resource.coverImage} alt={resource.title} className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-500" loading="lazy" />
        </div>
        <div className="p-4">
          <div className="flex items-center justify-between mb-2">
            <TopicChip topic={resource.topic} size="sm" />
            <ExternalLink className="w-3 h-3 text-muted-foreground/40" />
          </div>
          <h3 className="font-sans text-sm font-semibold text-foreground group-hover:text-primary transition-colors mb-1">
            {resource.title}
          </h3>
          <p className="text-xs text-muted-foreground line-clamp-2">{resource.shortDescription}</p>
        </div>
      </div>
    </Link>
  );
}
