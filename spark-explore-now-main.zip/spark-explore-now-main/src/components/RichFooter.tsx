import { Link } from "react-router-dom";

const footerLinks = {
  Discover: [
    { label: "Trending", href: "/trending" },
    { label: "Topics", href: "/topics" },
    { label: "Collections", href: "/collections" },
    { label: "Articles", href: "/articles" },
  ],
  Topics: [
    { label: "Technology", href: "/topics/technology" },
    { label: "AI & ML", href: "/topics/ai" },
    { label: "Business", href: "/topics/business" },
    { label: "Science", href: "/topics/science" },
    { label: "Design", href: "/topics/design" },
  ],
  Company: [
    { label: "About", href: "/about" },
    { label: "Contact", href: "/contact" },
    { label: "Submit", href: "/submit" },
  ],
};

export function RichFooter() {
  return (
    <footer className="border-t border-border/50 bg-secondary/30">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="font-editorial text-xl font-semibold text-foreground">Signal</Link>
            <p className="text-sm text-muted-foreground mt-3 max-w-xs">Discover what matters across the internet. Articles, tools, and insights — all in one place.</p>
          </div>
          {Object.entries(footerLinks).map(([section, links]) => (
            <div key={section}>
              <h4 className="font-sans text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">{section}</h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link to={link.href} className="text-sm text-muted-foreground hover:text-foreground transition-colors">{link.label}</Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-border/50 mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">© 2026 Signal. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">Privacy</a>
            <a href="#" className="hover:text-foreground transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
