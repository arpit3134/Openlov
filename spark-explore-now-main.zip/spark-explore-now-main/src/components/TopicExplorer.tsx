import { Link } from "react-router-dom";
import { topics } from "@/data/mockData";
import { ArrowRight } from "lucide-react";

export function TopicExplorer() {
  return (
    <section className="py-16 md:py-20">
      <div className="container">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-editorial text-2xl md:text-3xl font-medium text-foreground">Explore topics</h2>
            <p className="text-sm text-muted-foreground mt-1">Dive into subjects that matter to you</p>
          </div>
          <Link to="/topics" className="text-sm text-primary hover:underline hidden sm:flex items-center gap-1">
            All topics <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {topics.map((topic) => (
            <Link
              key={topic.slug}
              to={`/topics/${topic.slug}`}
              className="group flex flex-col items-center p-5 rounded-xl bg-card shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-0.5 text-center"
            >
              <span className="text-2xl mb-2">{topic.icon}</span>
              <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{topic.name}</span>
              <span className="text-[11px] text-muted-foreground mt-0.5">{topic.articleCount} articles</span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
