import { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { Search, Bookmark, Menu, X, ChevronDown } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";

const navItems = [
  { label: "Discover", href: "/discover" },
  { label: "Topics", href: "/topics" },
  { label: "Collections", href: "/collections" },
  { label: "Articles", href: "/articles" },
  { label: "Tools", href: "/resources", hasSubmenu: true },
  { label: "Trending", href: "/trending" },
];

const toolsSubmenu = [
  { label: "All Tools", href: "/resources" },
  { label: "Calculators", href: "/calculators" },
  { label: "AI Tools", href: "/resources?category=ai" },
  { label: "Developer Tools", href: "/resources?category=developer" },
  { label: "Design Tools", href: "/resources?category=design" },
  { label: "Productivity", href: "/resources?category=productivity" },
  { label: "Finance Tools", href: "/resources?category=finance" },
];

interface StickyHeaderProps {
  onSearchOpen?: () => void;
}

export function StickyHeader({ onSearchOpen }: StickyHeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [mobileToolsOpen, setMobileToolsOpen] = useState(false);
  const toolsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (toolsRef.current && !toolsRef.current.contains(e.target as Node)) {
        setToolsOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border/50">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="font-editorial text-xl font-semibold tracking-tight text-foreground">
          Signal
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) =>
            item.hasSubmenu ? (
              <div key={item.href} className="relative" ref={toolsRef}>
                <button
                  onClick={() => setToolsOpen(!toolsOpen)}
                  className="flex items-center gap-1 px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-secondary/60"
                >
                  {item.label}
                  <ChevronDown className={`w-3 h-3 transition-transform ${toolsOpen ? "rotate-180" : ""}`} />
                </button>
                {toolsOpen && (
                  <div className="absolute top-full left-0 mt-1 w-48 bg-popover border border-border rounded-lg shadow-lg py-1 z-50">
                    {toolsSubmenu.map((sub) => (
                      <Link
                        key={sub.href}
                        to={sub.href}
                        onClick={() => setToolsOpen(false)}
                        className="block px-4 py-2.5 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors"
                      >
                        {sub.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <Link
                key={item.href}
                to={item.href}
                className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-secondary/60"
              >
                {item.label}
              </Link>
            )
          )}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={onSearchOpen}
            className="p-2 rounded-full hover:bg-secondary/60 transition-colors text-muted-foreground hover:text-foreground"
            aria-label="Search"
          >
            <Search className="w-4 h-4" />
          </button>
          <ThemeToggle />
          <Link
            to="/bookmarks"
            className="p-2 rounded-full hover:bg-secondary/60 transition-colors text-muted-foreground hover:text-foreground hidden sm:flex"
            aria-label="Bookmarks"
          >
            <Bookmark className="w-4 h-4" />
          </Link>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="p-2 rounded-full hover:bg-secondary/60 transition-colors text-muted-foreground md:hidden"
            aria-label="Menu"
          >
            {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-border/50 bg-background pb-4">
          <nav className="container flex flex-col gap-1 pt-2">
            {navItems.map((item) =>
              item.hasSubmenu ? (
                <div key={item.href}>
                  <button
                    onClick={() => setMobileToolsOpen(!mobileToolsOpen)}
                    className="flex items-center justify-between w-full px-3 py-2.5 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-secondary/60"
                  >
                    {item.label}
                    <ChevronDown className={`w-3 h-3 transition-transform ${mobileToolsOpen ? "rotate-180" : ""}`} />
                  </button>
                  {mobileToolsOpen && (
                    <div className="pl-4">
                      {toolsSubmenu.map((sub) => (
                        <Link
                          key={sub.href}
                          to={sub.href}
                          onClick={() => { setMobileOpen(false); setMobileToolsOpen(false); }}
                          className="block px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-secondary/60"
                        >
                          {sub.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  key={item.href}
                  to={item.href}
                  onClick={() => setMobileOpen(false)}
                  className="px-3 py-2.5 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-secondary/60"
                >
                  {item.label}
                </Link>
              )
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
