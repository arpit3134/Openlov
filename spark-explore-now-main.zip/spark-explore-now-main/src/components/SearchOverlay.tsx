import { useState, useEffect, useRef } from "react";
import { Search, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { topics } from "@/data/mockData";

interface SearchOverlayProps {
  open: boolean;
  onClose: () => void;
}

export function SearchOverlay({ open, onClose }: SearchOverlayProps) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (open) {
      inputRef.current?.focus();
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
      onClose();
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-sm">
      <div className="container max-w-2xl pt-24 md:pt-32">
        <form onSubmit={handleSubmit} className="relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search everything…"
            className="w-full h-14 pl-14 pr-12 rounded-2xl bg-secondary text-base text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/20 font-sans"
          />
          <button type="button" onClick={onClose} className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-muted rounded-md">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </form>
        <div className="mt-8">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Popular topics</p>
          <div className="flex flex-wrap gap-2">
            {topics.filter(t => t.featured).map((t) => (
              <button
                key={t.slug}
                onClick={() => { navigate(`/topics/${t.slug}`); onClose(); }}
                className="px-3 py-1.5 rounded-full bg-secondary text-sm text-secondary-foreground hover:bg-secondary/80 transition-colors"
              >
                {t.icon} {t.name}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
