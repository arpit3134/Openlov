import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  href?: string;
  linkLabel?: string;
  className?: string;
}

export function SectionHeader({ title, subtitle, href, linkLabel = "View all", className }: SectionHeaderProps) {
  return (
    <div className={cn("flex items-end justify-between mb-8", className)}>
      <div>
        <h2 className="font-editorial text-2xl md:text-3xl font-medium text-foreground">{title}</h2>
        {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      {href && (
        <Link to={href} className="text-sm text-primary hover:underline hidden sm:flex items-center gap-1">
          {linkLabel} <ArrowRight className="w-3 h-3" />
        </Link>
      )}
    </div>
  );
}
