import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Calculator, Heart, Calendar, Code, Banknote, Receipt } from "lucide-react";
import type { Calculator as CalcType } from "@/data/calculators";

const categoryIcons: Record<string, React.ElementType> = {
  finance: Banknote,
  'tax-salary': Receipt,
  health: Heart,
  'date-time': Calendar,
  'math-utility': Calculator,
  developer: Code,
};

const categoryColors: Record<string, string> = {
  finance: 'bg-emerald-500/10 text-emerald-500',
  'tax-salary': 'bg-amber-500/10 text-amber-500',
  health: 'bg-rose-500/10 text-rose-500',
  'date-time': 'bg-blue-500/10 text-blue-500',
  'math-utility': 'bg-violet-500/10 text-violet-500',
  developer: 'bg-cyan-500/10 text-cyan-500',
};

export function CalculatorCard({ calculator, index = 0 }: { calculator: CalcType; index?: number }) {
  const Icon = categoryIcons[calculator.category] || Calculator;
  const color = categoryColors[calculator.category] || 'bg-primary/10 text-primary';

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.04, ease: [0.2, 0.8, 0.2, 1] }}
    >
    <Link
      to={`/calculators/${calculator.slug}`}
      className="group block rounded-xl border border-border bg-card p-5 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200"
    >
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <h3 className="font-medium text-foreground group-hover:text-primary transition-colors mb-1 text-sm">
        {calculator.name}
      </h3>
      <p className="text-xs text-muted-foreground line-clamp-2">{calculator.description}</p>
    </Link>
    </motion.div>
  );
}
