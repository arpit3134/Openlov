import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Article } from "@/data/types";
import { TopicChip } from "./TopicChip";
import { BookmarkButton } from "./BookmarkButton";

interface EditorialCardProps {
  article: Article;
  variant?: "feature" | "standard" | "compact";
  className?: string;
}

export function EditorialCard({ article, variant = "standard", className }: EditorialCardProps) {
  if (variant === "feature") {
    return (
      <Link to={`/articles/${article.slug}`} className={cn("group block", className)}>
        <div className="relative overflow-hidden rounded-xl shadow-card hover:shadow-card-hover transition-all duration-300">
          <div className="aspect-[16/9] md:aspect-[2/1] overflow-hidden">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-500"
              loading="lazy"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8">
            <TopicChip topic={article.topic} className="mb-3" />
            <h2 className="font-editorial text-2xl md:text-3xl lg:text-4xl font-medium text-primary-foreground leading-tight mb-3">
              {article.title}
            </h2>
            <p className="text-sm md:text-base text-primary-foreground/80 line-clamp-2 max-w-2xl mb-3">
              {article.excerpt}
            </p>
            <div className="flex items-center gap-3 text-xs text-primary-foreground/60">
              <span>{article.author.name}</span>
              <span>·</span>
              <span>{article.readTime} min read</span>
            </div>
          </div>
        </div>
      </Link>
    );
  }

  if (variant === "compact") {
    return (
      <Link to={`/articles/${article.slug}`} className={cn("group flex gap-4 items-start", className)}>
        <div className="w-20 h-20 md:w-24 md:h-24 rounded-lg overflow-hidden flex-shrink-0 shadow-card">
          <img src={article.image} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
        </div>
        <div className="flex-1 min-w-0">
          <TopicChip topic={article.topic} size="sm" className="mb-1.5" />
          <h3 className="font-editorial text-base md:text-lg font-medium text-foreground leading-snug group-hover:text-primary transition-colors line-clamp-2">
            {article.title}
          </h3>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1.5">
            <span>{article.readTime} min</span>
            <span>·</span>
            <span>{new Date(article.publishedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link to={`/articles/${article.slug}`} className={cn("group block", className)}>
      <div className="overflow-hidden rounded-xl shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-0.5 bg-card">
        <div className="aspect-[16/10] overflow-hidden">
          <img src={article.image} alt={article.title} className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-500" loading="lazy" />
        </div>
        <div className="p-5">
          <div className="flex items-center justify-between mb-2.5">
            <TopicChip topic={article.topic} size="sm" />
            <BookmarkButton />
          </div>
          <h3 className="font-editorial text-lg md:text-xl font-medium text-foreground leading-snug group-hover:text-primary transition-colors mb-2 line-clamp-2">
            {article.title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{article.excerpt}</p>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>{article.author.name}</span>
            <span>·</span>
            <span>{article.readTime} min read</span>
            <span>·</span>
            <span>{new Date(article.publishedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
