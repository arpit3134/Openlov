import { useState, useEffect } from "react";
import { Search } from "lucide-react";
import { useNavigate } from "react-router-dom";

const placeholders = [
  "Search articles, topics, and resources…",
  "Explore the future of AI…",
  "Discover startup strategies…",
  "Find design inspiration…",
  "Learn about emerging science…",
];

export function DiscoveryHero() {
  const [placeholderIdx, setPlaceholderIdx] = useState(0);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const interval = setInterval(() => {
      setPlaceholderIdx((i) => (i + 1) % placeholders.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  };

  return (
    <section className="py-20 md:py-28 lg:py-32">
      <div className="container max-w-3xl text-center">
        <h1 className="font-editorial text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-medium text-foreground leading-[1.1] mb-6 animate-fade-in">
          The signal for<br />what's next
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground mb-10 animate-fade-in" style={{ animationDelay: "0.1s" }}>
          Discover articles, ideas, tools, and insights across every topic that matters.
        </p>
        <form onSubmit={handleSubmit} className="relative max-w-xl mx-auto animate-fade-in" style={{ animationDelay: "0.2s" }}>
          <div className="relative">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={placeholders[placeholderIdx]}
              className="w-full h-14 pl-13 pr-5 rounded-full bg-background border-0 shadow-hero text-base text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-shadow font-sans"
              style={{ paddingLeft: "3.25rem" }}
            />
          </div>
        </form>
      </div>
    </section>
  );
}
