import { useState } from "react";
import { Bookmark } from "lucide-react";
import { cn } from "@/lib/utils";

export function BookmarkButton({ className }: { className?: string }) {
  const [saved, setSaved] = useState(false);

  return (
    <button
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); setSaved(!saved); }}
      className={cn("p-1 rounded-full hover:bg-secondary transition-colors", className)}
      aria-label={saved ? "Remove bookmark" : "Save"}
    >
      <Bookmark className={cn("w-3.5 h-3.5", saved ? "fill-primary text-primary" : "text-muted-foreground")} />
    </button>
  );
}
