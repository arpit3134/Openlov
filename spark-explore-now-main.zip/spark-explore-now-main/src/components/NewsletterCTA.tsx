import { useState } from "react";
import { ArrowRight } from "lucide-react";

export function NewsletterCTA() {
  const [email, setEmail] = useState("");

  return (
    <section className="py-16 md:py-20">
      <div className="container max-w-2xl text-center">
        <h2 className="font-editorial text-2xl md:text-3xl font-medium text-foreground mb-3">Stay in the loop</h2>
        <p className="text-muted-foreground mb-8">Get the most important discoveries delivered to your inbox every week. No noise, just signal.</p>
        <form
          onSubmit={(e) => { e.preventDefault(); setEmail(""); }}
          className="flex gap-2 max-w-md mx-auto"
        >
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="your@email.com"
            className="flex-1 h-12 px-5 rounded-full bg-secondary border-0 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/20 transition-shadow font-sans"
            required
          />
          <button
            type="submit"
            className="h-12 px-6 rounded-full bg-foreground text-background text-sm font-medium hover:bg-foreground/90 transition-colors flex items-center gap-2"
          >
            Subscribe <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </section>
  );
}
